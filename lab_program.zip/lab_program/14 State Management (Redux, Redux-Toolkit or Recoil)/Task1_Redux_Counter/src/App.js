import React, { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { increment, decrement, reset, incrementBy } from './store/counterReducer';
import './App.css';

export default function App() {
  const count    = useSelector(function (state) { return state.count; });
  const dispatch = useDispatch();
  const [amount, setAmount] = useState(5);

  return (
    <div className="container">
      <div className="card">
        <h1 className="title">Redux Counter</h1>
        <p className="subtitle">State Task 1 — Plain Redux (createStore + Reducer + Actions)</p>

        <div className="counter-display">
          <span className={'count ' + (count > 0 ? 'pos' : count < 0 ? 'neg' : '')}>
            {count}
          </span>
        </div>

        <div className="btn-group">
          <button className="btn btn-red"   onClick={function () { dispatch(decrement()); }}>− Decrement</button>
          <button className="btn btn-gray"  onClick={function () { dispatch(reset()); }}>Reset</button>
          <button className="btn btn-green" onClick={function () { dispatch(increment()); }}>+ Increment</button>
        </div>

        <div className="amount-row">
          <label>Increment by:</label>
          <input
            type="number"
            className="num-inp"
            value={amount}
            onChange={function (e) { setAmount(Number(e.target.value)); }}
          />
          <button className="btn btn-blue" onClick={function () { dispatch(incrementBy(amount)); }}>
            Add {amount}
          </button>
        </div>

        <div className="explain">
          <p><strong>Plain Redux Flow:</strong></p>
          <ol>
            <li><code>createStore(reducer)</code> — creates the store</li>
            <li><code>dispatch(increment())</code> — sends action to reducer</li>
            <li>Reducer returns new state → component re-renders</li>
            <li><code>useSelector</code> reads <code>state.count</code> from store</li>
          </ol>
        </div>
      </div>
    </div>
  );
}
