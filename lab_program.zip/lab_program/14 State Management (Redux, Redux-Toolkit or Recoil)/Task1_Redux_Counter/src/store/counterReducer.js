// store/counterReducer.js — Plain Redux (without Redux Toolkit)

// 1. Define action type constants
const INCREMENT        = 'INCREMENT';
const DECREMENT        = 'DECREMENT';
const RESET            = 'RESET';
const INCREMENT_BY     = 'INCREMENT_BY';

// 2. Action creators — functions that return action objects
export function increment()              { return { type: INCREMENT }; }
export function decrement()              { return { type: DECREMENT }; }
export function reset()                  { return { type: RESET }; }
export function incrementBy(amount)      { return { type: INCREMENT_BY, payload: amount }; }

// 3. Initial state
const initialState = { count: 0 };

// 4. Reducer — pure function: (state, action) => newState
function counterReducer(state, action) {
  if (state === undefined) state = initialState;

  switch (action.type) {
    case INCREMENT:
      return { count: state.count + 1 };
    case DECREMENT:
      return { count: state.count - 1 };
    case RESET:
      return { count: 0 };
    case INCREMENT_BY:
      return { count: state.count + action.payload };
    default:
      return state;
  }
}

export default counterReducer;
