// store/store.js — Plain Redux store (no Redux Toolkit)
import { createStore } from 'redux';
import counterReducer  from './counterReducer';

// createStore(reducer) — creates the Redux store
const store = createStore(counterReducer);

export default store;
