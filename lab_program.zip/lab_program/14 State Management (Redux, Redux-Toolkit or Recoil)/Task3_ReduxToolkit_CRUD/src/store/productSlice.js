// store/productSlice.js — Redux Toolkit slice
import { createSlice } from '@reduxjs/toolkit';

const productSlice = createSlice({
  name: 'products',
  initialState: {
    items: [
      { id: 1, name: 'Laptop',      price: 75000, category: 'Electronics', stock: 10 },
      { id: 2, name: 'Headphones',  price: 2499,  category: 'Electronics', stock: 25 },
      { id: 3, name: 'Desk Chair',  price: 8999,  category: 'Furniture',   stock: 5  },
      { id: 4, name: 'Coffee Mug',  price: 299,   category: 'Kitchen',     stock: 50 },
    ],
    nextId: 5,
  },
  reducers: {
    // ADD — push a new product
    addProduct: function (state, action) {
      state.items.push({ ...action.payload, id: state.nextId });
      state.nextId += 1;
    },
    // UPDATE — replace entire product (PUT-style)
    updateProduct: function (state, action) {
      var idx = state.items.findIndex(function (p) { return p.id === action.payload.id; });
      if (idx !== -1) state.items[idx] = action.payload;
    },
    // DELETE — remove by id
    deleteProduct: function (state, action) {
      state.items = state.items.filter(function (p) { return p.id !== action.payload; });
    },
    // PATCH — update only stock
    updateStock: function (state, action) {
      var item = state.items.find(function (p) { return p.id === action.payload.id; });
      if (item) item.stock = action.payload.stock;
    },
  },
});

export const { addProduct, updateProduct, deleteProduct, updateStock } = productSlice.actions;
export default productSlice.reducer;
