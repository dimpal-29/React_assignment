import React, { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { addProduct, updateProduct, deleteProduct, updateStock } from './store/productSlice';
import './App.css';

const CATEGORIES = ['Electronics', 'Furniture', 'Kitchen', 'Clothing', 'Books'];
const EMPTY_FORM  = { name: '', price: '', category: 'Electronics', stock: '' };

export default function App() {
  const products = useSelector(function (s) { return s.products.items; });
  const dispatch  = useDispatch();

  const [form, setForm]       = useState(EMPTY_FORM);
  const [editId, setEditId]   = useState(null);
  const [search, setSearch]   = useState('');
  const [catFilter, setCat]   = useState('All');

  function handleChange(e) {
    setForm(function (prev) { return { ...prev, [e.target.name]: e.target.value }; });
  }

  // ADD
  function handleAdd() {
    if (!form.name || !form.price) return alert('Name and Price required');
    dispatch(addProduct({ name: form.name, price: Number(form.price), category: form.category, stock: Number(form.stock) || 0 }));
    setForm(EMPTY_FORM);
  }

  // UPDATE
  function handleUpdate() {
    dispatch(updateProduct({ id: editId, name: form.name, price: Number(form.price), category: form.category, stock: Number(form.stock) }));
    setForm(EMPTY_FORM); setEditId(null);
  }

  // DELETE
  function handleDelete(id) {
    if (window.confirm('Delete this product?')) dispatch(deleteProduct(id));
  }

  // PATCH stock
  function handleStockChange(id, val) {
    dispatch(updateStock({ id, stock: Number(val) }));
  }

  function startEdit(p) {
    setEditId(p.id);
    setForm({ name: p.name, price: p.price, category: p.category, stock: p.stock });
  }

  // Filter + search
  var visible = products.filter(function (p) {
    var matchCat    = catFilter === 'All' || p.category === catFilter;
    var matchSearch = p.name.toLowerCase().includes(search.toLowerCase());
    return matchCat && matchSearch;
  });

  var totalValue = products.reduce(function (sum, p) { return sum + p.price * p.stock; }, 0);

  return (
    <div className="app">
      <header className="app-header">
        <h1>🛒 Redux Toolkit — Products CRUD</h1>
        <p>State Task 3 · createSlice · addProduct · updateProduct · deleteProduct · updateStock</p>
      </header>

      {/* Stats */}
      <div className="stats-row">
        <div className="stat-card"><span className="stat-n">{products.length}</span><span>Total Products</span></div>
        <div className="stat-card"><span className="stat-n">₹{totalValue.toLocaleString()}</span><span>Inventory Value</span></div>
        <div className="stat-card"><span className="stat-n">{products.reduce(function(s,p){return s+p.stock;},0)}</span><span>Total Stock</span></div>
      </div>

      {/* Form */}
      <div className="section form-section">
        <h2 className="section-title">{editId ? '✏️ Edit Product (updateProduct)' : '➕ Add Product (addProduct)'}</h2>
        <div className="form-row">
          <input  name="name"     placeholder="Product name"  value={form.name}     onChange={handleChange} className="inp" />
          <input  name="price"    placeholder="Price (₹)"     value={form.price}    onChange={handleChange} className="inp" type="number" />
          <input  name="stock"    placeholder="Stock qty"     value={form.stock}    onChange={handleChange} className="inp" type="number" />
          <select name="category" value={form.category} onChange={handleChange} className="inp">
            {CATEGORIES.map(function (c) { return <option key={c}>{c}</option>; })}
          </select>
          {editId ? (
            <>
              <button className="btn btn-yellow" onClick={handleUpdate}>💾 Update</button>
              <button className="btn btn-gray"   onClick={function () { setEditId(null); setForm(EMPTY_FORM); }}>Cancel</button>
            </>
          ) : (
            <button className="btn btn-green" onClick={handleAdd}>➕ Add</button>
          )}
        </div>
      </div>

      {/* Filter + Search */}
      <div className="filter-bar">
        <input className="inp search-inp" placeholder="🔍 Search products…" value={search} onChange={function(e){setSearch(e.target.value);}} />
        <div className="cat-tabs">
          {['All', ...CATEGORIES].map(function (c) {
            return <button key={c} className={'tab ' + (catFilter===c?'active':'')} onClick={function(){setCat(c);}}>{c}</button>;
          })}
        </div>
      </div>

      {/* Table */}
      <div className="section">
        <h2 className="section-title">📦 Products ({visible.length})</h2>
        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr><th>ID</th><th>Name</th><th>Category</th><th>Price</th><th>Stock</th><th>Actions</th></tr>
            </thead>
            <tbody>
              {visible.length === 0 && (
                <tr><td colSpan="6" style={{textAlign:'center',padding:'24px',color:'#a0aec0'}}>No products found</td></tr>
              )}
              {visible.map(function (p) {
                return (
                  <tr key={p.id}>
                    <td>{p.id}</td>
                    <td><strong>{p.name}</strong></td>
                    <td><span className="cat-badge">{p.category}</span></td>
                    <td>₹{Number(p.price).toLocaleString()}</td>
                    <td>
                      <input
                        type="number"
                        className="stock-inp"
                        value={p.stock}
                        onChange={function (e) { handleStockChange(p.id, e.target.value); }}
                        title="Edit stock inline (PATCH)"
                      />
                    </td>
                    <td>
                      <button className="btn-sm btn-edit"   onClick={function () { startEdit(p); }}>✏️ Edit</button>
                      <button className="btn-sm btn-delete" onClick={function () { handleDelete(p.id); }}>🗑 Del</button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      <div className="explain section">
        <strong>Redux Toolkit vs Plain Redux:</strong>
        <ul>
          <li><code>createSlice()</code> — combines reducer + action creators in one place</li>
          <li><code>configureStore()</code> — sets up store with devtools automatically</li>
          <li>No need to write switch/case reducers manually</li>
          <li>Immer is built-in — you can "mutate" state directly inside reducers</li>
        </ul>
      </div>
    </div>
  );
}
