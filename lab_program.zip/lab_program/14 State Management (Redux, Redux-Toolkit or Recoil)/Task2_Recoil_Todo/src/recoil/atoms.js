// src/recoil/atoms.js
import { atom, selector } from 'recoil';

// atom — the basic unit of Recoil state
// Any component that reads this atom will re-render when it changes
export const todoListAtom = atom({
  key:     'todoListAtom',  // unique key for this atom
  default: [
    { id: 1, text: 'Learn React',        completed: true  },
    { id: 2, text: 'Learn Recoil',       completed: false },
    { id: 3, text: 'Build a Todo App',   completed: false },
  ],
});

// atom for the filter value
export const filterAtom = atom({
  key:     'filterAtom',
  default: 'All',  // 'All' | 'Active' | 'Completed'
});

// selector — derived state (computed from atoms)
// Re-calculates automatically when todoListAtom or filterAtom changes
export const filteredTodosSelector = selector({
  key: 'filteredTodosSelector',
  get: function ({ get }) {
    const todos  = get(todoListAtom);
    const filter = get(filterAtom);
    if (filter === 'Active')    return todos.filter(function (t) { return !t.completed; });
    if (filter === 'Completed') return todos.filter(function (t) { return  t.completed; });
    return todos;
  },
});

// selector for stats
export const statsSelector = selector({
  key: 'statsSelector',
  get: function ({ get }) {
    const todos = get(todoListAtom);
    return {
      total:     todos.length,
      completed: todos.filter(function (t) { return t.completed; }).length,
      active:    todos.filter(function (t) { return !t.completed; }).length,
    };
  },
});
