import React, { useState } from 'react';
import { useRecoilState, useRecoilValue, useSetRecoilState } from 'recoil';
import { todoListAtom, filterAtom, filteredTodosSelector, statsSelector } from './recoil/atoms';
import './App.css';

// ─── Stats bar ────────────────────────────────────────────────────────────────
function StatsBar() {
  const stats = useRecoilValue(statsSelector); // read-only selector
  return (
    <div className="stats-bar">
      <div className="stat"><span className="stat-num">{stats.total}</span><span className="stat-label">Total</span></div>
      <div className="stat"><span className="stat-num green">{stats.completed}</span><span className="stat-label">Done</span></div>
      <div className="stat"><span className="stat-num blue">{stats.active}</span><span className="stat-label">Active</span></div>
    </div>
  );
}

// ─── Filter tabs ──────────────────────────────────────────────────────────────
function FilterTabs() {
  const [filter, setFilter] = useRecoilState(filterAtom);
  return (
    <div className="filter-tabs">
      {['All', 'Active', 'Completed'].map(function (f) {
        return (
          <button
            key={f}
            className={'tab ' + (filter === f ? 'active' : '')}
            onClick={function () { setFilter(f); }}
          >{f}</button>
        );
      })}
    </div>
  );
}

// ─── Single Todo item ─────────────────────────────────────────────────────────
function TodoItem({ todo }) {
  const setTodos = useSetRecoilState(todoListAtom);

  function toggle() {
    setTodos(function (prev) {
      return prev.map(function (t) { return t.id === todo.id ? { ...t, completed: !t.completed } : t; });
    });
  }

  function remove() {
    setTodos(function (prev) { return prev.filter(function (t) { return t.id !== todo.id; }); });
  }

  return (
    <div className={'todo-item ' + (todo.completed ? 'done' : '')}>
      <input type="checkbox" checked={todo.completed} onChange={toggle} className="todo-check" />
      <span className="todo-text">{todo.text}</span>
      <button className="btn-remove" onClick={remove}>✕</button>
    </div>
  );
}

// ─── Todo List ────────────────────────────────────────────────────────────────
function TodoList() {
  const filteredTodos = useRecoilValue(filteredTodosSelector); // derived selector

  if (filteredTodos.length === 0) {
    return <p className="empty-msg">No tasks here yet!</p>;
  }

  return (
    <div className="todo-list">
      {filteredTodos.map(function (todo) {
        return <TodoItem key={todo.id} todo={todo} />;
      })}
    </div>
  );
}

// ─── Add Todo ─────────────────────────────────────────────────────────────────
function AddTodo() {
  const [text, setText]  = useState('');
  const setTodos = useSetRecoilState(todoListAtom);

  function handleAdd() {
    if (!text.trim()) return;
    setTodos(function (prev) {
      return [...prev, { id: Date.now(), text: text.trim(), completed: false }];
    });
    setText('');
  }

  function handleKey(e) {
    if (e.key === 'Enter') handleAdd();
  }

  return (
    <div className="add-row">
      <input
        className="inp"
        placeholder="Add a new task and press Enter…"
        value={text}
        onChange={function (e) { setText(e.target.value); }}
        onKeyDown={handleKey}
      />
      <button className="btn btn-add" onClick={handleAdd}>Add</button>
    </div>
  );
}

// ─── Root App ─────────────────────────────────────────────────────────────────
export default function App() {
  return (
    <div className="container">
      <div className="card">
        <h1 className="title">Recoil Todo List</h1>
        <p className="subtitle">State Task 2 — Recoil: atom · selector · useRecoilState</p>

        <StatsBar />
        <AddTodo />
        <FilterTabs />
        <TodoList />

        <div className="explain">
          <strong>Recoil Concepts:</strong>
          <ul>
            <li><code>atom()</code> — global state unit; components subscribe automatically</li>
            <li><code>selector()</code> — derived/computed state from atoms</li>
            <li><code>useRecoilState()</code> — like useState but global</li>
            <li><code>useRecoilValue()</code> — read-only subscription</li>
            <li><code>useSetRecoilState()</code> — write-only, no re-render on read</li>
            <li><code>RecoilRoot</code> — wraps the app (like Redux Provider)</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
