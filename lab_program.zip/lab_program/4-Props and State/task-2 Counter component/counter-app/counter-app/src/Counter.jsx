import React, { useState } from "react";

const Counter = () => {
  // useState hook — count starts at 0
  const [count, setCount] = useState(0);

  // Increment function
  const increment = () => setCount(count + 1);

  // Decrement function (won't go below 0)
  const decrement = () => setCount(count > 0 ? count - 1 : 0);

  // Reset function
  const reset = () => setCount(0);

  return (
    <div style={styles.container}>
      <h1 style={styles.title}>Counter App</h1>

      {/* Display current count */}
      <div style={styles.countBox}>
        <p style={styles.countLabel}>Current Count</p>
        <h2 style={styles.countValue}>{count}</h2>
      </div>

      {/* Buttons */}
      <div style={styles.buttonRow}>
        <button style={{ ...styles.button, backgroundColor: "#e53935" }} onClick={decrement}>
          − Decrement
        </button>
        <button style={{ ...styles.button, backgroundColor: "#757575" }} onClick={reset}>
          ↺ Reset
        </button>
        <button style={{ ...styles.button, backgroundColor: "#43a047" }} onClick={increment}>
          + Increment
        </button>
      </div>
    </div>
  );
};

const styles = {
  container: {
    maxWidth: "420px",
    margin: "80px auto",
    padding: "40px",
    backgroundColor: "#f3f4fb",
    borderRadius: "14px",
    boxShadow: "0 6px 20px rgba(0,0,0,0.12)",
    fontFamily: "Arial, sans-serif",
    textAlign: "center",
  },
  title: {
    fontSize: "1.8rem",
    color: "#3f51b5",
    marginBottom: "24px",
  },
  countBox: {
    backgroundColor: "#ffffff",
    borderRadius: "10px",
    padding: "24px",
    marginBottom: "28px",
    boxShadow: "0 2px 8px rgba(0,0,0,0.08)",
  },
  countLabel: {
    fontSize: "0.95rem",
    color: "#888",
    marginBottom: "8px",
  },
  countValue: {
    fontSize: "3.5rem",
    fontWeight: "bold",
    color: "#3f51b5",
    margin: 0,
  },
  buttonRow: {
    display: "flex",
    justifyContent: "center",
    gap: "12px",
    flexWrap: "wrap",
  },
  button: {
    padding: "12px 22px",
    fontSize: "1rem",
    color: "#fff",
    border: "none",
    borderRadius: "8px",
    cursor: "pointer",
    fontWeight: "bold",
  },
};

export default Counter;
