import React from "react";

// UserCard accepts name, age, and location as props
const UserCard = ({ name, age, location }) => {
  return (
    <div style={styles.card}>
      {/* Avatar Circle */}
      <div style={styles.avatar}>
        {name.charAt(0).toUpperCase()}
      </div>

      {/* User Info */}
      <h2 style={styles.name}>{name}</h2>

      <div style={styles.infoRow}>
        <span style={styles.label}>Age</span>
        <span style={styles.value}>{age} years</span>
      </div>

      <div style={styles.infoRow}>
        <span style={styles.label}>Location</span>
        <span style={styles.value}>{location}</span>
      </div>
    </div>
  );
};

const styles = {
  card: {
    width: "260px",
    margin: "20px auto",
    padding: "30px 24px",
    backgroundColor: "#ffffff",
    borderRadius: "14px",
    boxShadow: "0 6px 20px rgba(0,0,0,0.12)",
    fontFamily: "Arial, sans-serif",
    textAlign: "center",
  },
  avatar: {
    width: "70px",
    height: "70px",
    borderRadius: "50%",
    backgroundColor: "#3f51b5",
    color: "#fff",
    fontSize: "2rem",
    fontWeight: "bold",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    margin: "0 auto 16px",
  },
  name: {
    fontSize: "1.4rem",
    color: "#1a1a2e",
    marginBottom: "16px",
  },
  infoRow: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "8px 0",
    borderTop: "1px solid #f0f0f0",
  },
  label: {
    fontSize: "0.9rem",
    color: "#888",
  },
  value: {
    fontSize: "0.95rem",
    color: "#333",
    fontWeight: "bold",
  },
};

export default UserCard;
