import React from "react";
import UserCard from "./UserCard";

function App() {
  return (
    <div style={{ backgroundColor: "#f4f6f9", minHeight: "100vh", padding: "40px 20px" }}>
      <h1 style={{ textAlign: "center", fontFamily: "Arial", color: "#3f51b5", marginBottom: "10px" }}>
        User Cards
      </h1>

      {/* Passing name, age, location as props */}
      <UserCard name="Alice Johnson" age={28} location="New York, USA" />
      <UserCard name="Bob Smith"     age={34} location="London, UK" />
      <UserCard name="Charlie Lee"   age={22} location="Tokyo, Japan" />
    </div>
  );
}

export default App;
