import React, { useState } from "react";

const LiveForm = () => {
  // State to store the input value
  const [inputValue, setInputValue] = useState("");

  // Event handler — updates state as user types
  const handleChange = (event) => {
    setInputValue(event.target.value);
  };

  return (
    <div style={styles.container}>
      <h1 style={styles.title}>Live Form Input</h1>

      {/* Input Field */}
      <div style={styles.formGroup}>
        <label style={styles.label}>Type something below:</label>
        <input
          type="text"
          value={inputValue}
          onChange={handleChange}
          placeholder="Start typing..."
          style={styles.input}
        />
      </div>

      {/* Live Display Box */}
      <div style={styles.displayBox}>
        <p style={styles.displayLabel}>Live Output:</p>
        <p style={styles.displayValue}>
          {inputValue ? inputValue : <span style={styles.placeholder}>Nothing typed yet...</span>}
        </p>
      </div>

      {/* Character Count */}
      <p style={styles.charCount}>
        Characters typed: <strong>{inputValue.length}</strong>
      </p>

      {/* Clear Button */}
      {inputValue && (
        <button style={styles.clearBtn} onClick={() => setInputValue("")}>
          ✕ Clear
        </button>
      )}
    </div>
  );
};

const styles = {
  container: {
    maxWidth: "460px",
    margin: "70px auto",
    padding: "40px",
    backgroundColor: "#fff8e1",
    borderRadius: "14px",
    boxShadow: "0 6px 20px rgba(0,0,0,0.12)",
    fontFamily: "Arial, sans-serif",
  },
  title: {
    fontSize: "1.5rem",
    color: "#e65100",
    textAlign: "center",
    marginBottom: "28px",
  },
  formGroup: {
    marginBottom: "22px",
  },
  label: {
    display: "block",
    fontSize: "0.95rem",
    color: "#555",
    marginBottom: "8px",
    fontWeight: "bold",
  },
  input: {
    width: "100%",
    padding: "12px 14px",
    fontSize: "1rem",
    border: "2px solid #ffcc80",
    borderRadius: "8px",
    outline: "none",
    boxSizing: "border-box",
    backgroundColor: "#fff",
    color: "#333",
  },
  displayBox: {
    backgroundColor: "#ffffff",
    border: "2px dashed #ffb74d",
    borderRadius: "10px",
    padding: "18px 20px",
    marginBottom: "14px",
    minHeight: "70px",
  },
  displayLabel: {
    fontSize: "0.85rem",
    color: "#888",
    margin: "0 0 6px",
  },
  displayValue: {
    fontSize: "1.2rem",
    color: "#bf360c",
    fontWeight: "bold",
    margin: 0,
    wordBreak: "break-word",
  },
  placeholder: {
    color: "#bbb",
    fontWeight: "normal",
    fontStyle: "italic",
  },
  charCount: {
    fontSize: "0.9rem",
    color: "#777",
    textAlign: "right",
    margin: "0 0 12px",
  },
  clearBtn: {
    display: "block",
    margin: "0 auto",
    padding: "10px 24px",
    fontSize: "0.95rem",
    backgroundColor: "#ef5350",
    color: "#fff",
    border: "none",
    borderRadius: "8px",
    cursor: "pointer",
    fontWeight: "bold",
  },
};

export default LiveForm;
