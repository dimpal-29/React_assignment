import React, { useState } from "react";

const ClickButton = () => {
  // State to track if button is clicked
  const [clicked, setClicked] = useState(false);

  // Event handler — changes state on click
  const handleClick = () => {
    setClicked(true);
  };

  return (
    <div style={styles.container}>
      <h1 style={styles.title}>Event Handling in React</h1>

      {/* Display text based on state */}
      <div style={styles.textBox}>
        <p style={{
          ...styles.statusText,
          color: clicked ? "#2e7d32" : "#c62828",
        }}>
          {clicked ? "Clicked!" : "Not Clicked"}
        </p>
      </div>

      {/* Button with onClick event handler */}
      <button
        style={{
          ...styles.button,
          backgroundColor: clicked ? "#9e9e9e" : "#3f51b5",
        }}
        onClick={handleClick}
        disabled={clicked}
      >
        {clicked ? "Already Clicked!" : "Click Me"}
      </button>

      {/* Reset Button */}
      {clicked && (
        <button style={styles.resetBtn} onClick={() => setClicked(false)}>
          ↺ Reset
        </button>
      )}
    </div>
  );
};

const styles = {
  container: {
    maxWidth: "420px",
    margin: "80px auto",
    padding: "40px",
    backgroundColor: "#f5f5ff",
    borderRadius: "14px",
    boxShadow: "0 6px 20px rgba(0,0,0,0.12)",
    fontFamily: "Arial, sans-serif",
    textAlign: "center",
  },
  title: {
    fontSize: "1.5rem",
    color: "#3f51b5",
    marginBottom: "28px",
  },
  textBox: {
    backgroundColor: "#ffffff",
    borderRadius: "10px",
    padding: "24px",
    marginBottom: "24px",
    boxShadow: "0 2px 8px rgba(0,0,0,0.07)",
  },
  statusText: {
    fontSize: "2rem",
    fontWeight: "bold",
    margin: 0,
    transition: "color 0.3s ease",
  },
  button: {
    padding: "12px 30px",
    fontSize: "1rem",
    color: "#fff",
    border: "none",
    borderRadius: "8px",
    cursor: "pointer",
    fontWeight: "bold",
    marginBottom: "12px",
  },
  resetBtn: {
    display: "block",
    margin: "10px auto 0",
    padding: "10px 24px",
    fontSize: "0.95rem",
    backgroundColor: "#ff7043",
    color: "#fff",
    border: "none",
    borderRadius: "8px",
    cursor: "pointer",
    fontWeight: "bold",
  },
};

export default ClickButton;
