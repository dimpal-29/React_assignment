import React from "react";
import ClickButton from "./ClickButton";

function App() {
  return (
    <div>
      <ClickButton />
    </div>
  );
}

export default App;
