import React from "react";
import HelloReact from "./HelloReact";

function App() {
  return (
    <div>
      {/* Rendering the HelloReact component */}
      <HelloReact />
    </div>
  );
}

export default App;
