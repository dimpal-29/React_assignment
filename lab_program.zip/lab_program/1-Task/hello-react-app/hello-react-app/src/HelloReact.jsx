import React from "react";

// Basic functional component that displays "Hello, React!"
const HelloReact = () => {
  return (
    <div style={styles.container}>
      <h1 style={styles.heading}>Hello, React!</h1>
      <p style={styles.subtext}>
        Welcome! This app was created using{" "}
        <strong>create-react-app</strong>.
      </p>
    </div>
  );
};

const styles = {
  container: {
    maxWidth: "500px",
    margin: "100px auto",
    padding: "40px",
    backgroundColor: "#e8f5e9",
    borderRadius: "12px",
    boxShadow: "0 4px 14px rgba(0,0,0,0.1)",
    fontFamily: "Arial, sans-serif",
    textAlign: "center",
  },
  heading: {
    fontSize: "2.5rem",
    color: "#2e7d32",
    marginBottom: "16px",
  },
  subtext: {
    fontSize: "1rem",
    color: "#555",
    lineHeight: "1.7",
  },
};

export default HelloReact;
