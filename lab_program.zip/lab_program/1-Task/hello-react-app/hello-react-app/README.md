# Hello React App

A basic React app created using **create-react-app**.

## Project Structure

```
hello-react-app/
├── public/
│   └── index.html        ← Root HTML file
├── src/
│   ├── index.js          ← Entry point (mounts App into index.html)
│   ├── App.js            ← Main App component
│   └── HelloReact.jsx    ← Component that displays "Hello, React!"
└── package.json          ← Dependencies & scripts
```

## How to Run

### Step 1 — Install Node.js
Download from: https://nodejs.org (LTS version recommended)

### Step 2 — Install dependencies
```bash
cd hello-react-app
npm install
```

### Step 3 — Start the app
```bash
npm start
```

App will open at: **http://localhost:3000**

## How create-react-app Works

1. `public/index.html` → Has `<div id="root">` where React injects the app
2. `src/index.js`      → Creates a React root and renders `<App />`
3. `src/App.js`        → Main component that uses `<HelloReact />`
4. `src/HelloReact.jsx`→ Displays "Hello, React!" on the page
