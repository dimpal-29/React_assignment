import React, { createContext, useContext, useState } from 'react';

// 1. CREATE the context
const ThemeContext = createContext();

// 2. PROVIDER — wraps the whole app and shares theme state
export function ThemeProvider({ children }) {
  const [theme, setTheme] = useState('light'); // 'light' | 'dark'

  function toggleTheme() {
    setTheme(function (prev) { return prev === 'light' ? 'dark' : 'light'; });
  }

  return (
    // Every child component can read "theme" and "toggleTheme" via useTheme()
    <ThemeContext.Provider value={{ theme, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  );
}

// 3. Custom hook — any component calls useTheme() to get context
export function useTheme() {
  return useContext(ThemeContext);
}
