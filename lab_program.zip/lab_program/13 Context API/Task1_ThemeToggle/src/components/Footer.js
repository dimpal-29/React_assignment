import React from 'react';
import { useTheme } from '../context/ThemeContext';

function Footer() {
  const { theme } = useTheme();
  return (
    <footer className={'footer ' + theme}>
      <p>Context API Theme Toggle — current theme: <strong>{theme}</strong></p>
      <p style={{ fontSize: '0.75rem', marginTop: 4, opacity: 0.6 }}>
        All components read the same theme from ThemeContext — no prop drilling!
      </p>
    </footer>
  );
}

export default Footer;
