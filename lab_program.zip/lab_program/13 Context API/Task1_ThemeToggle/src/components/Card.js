import React from 'react';
import { useTheme } from '../context/ThemeContext';

function Card({ title, body }) {
  const { theme } = useTheme();
  return (
    <div className={'card ' + theme}>
      <h3 className="card-title">{title}</h3>
      <p className="card-body">{body}</p>
    </div>
  );
}

export default Card;
