import React from 'react';
import { useTheme } from '../context/ThemeContext';

// Navbar reads theme from context — no props needed!
function Navbar() {
  const { theme, toggleTheme } = useTheme();

  return (
    <nav className={'navbar ' + theme}>
      <span className="nav-brand">⚛️ ThemeApp</span>
      <button className={'toggle-btn ' + theme} onClick={toggleTheme}>
        {theme === 'light' ? '🌙 Dark Mode' : '☀️ Light Mode'}
      </button>
    </nav>
  );
}

export default Navbar;
