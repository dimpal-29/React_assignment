import React from 'react';
import { ThemeProvider, useTheme } from './context/ThemeContext';
import Navbar  from './components/Navbar';
import Card    from './components/Card';
import Footer  from './components/Footer';
import './App.css';

// Hero section also reads theme from context
function Hero() {
  const { theme, toggleTheme } = useTheme();
  return (
    <div className={'hero ' + theme}>
      <h1>Context API — Theme Toggle</h1>
      <p>
        The theme state lives in <code>ThemeContext</code>. Every component —
        Navbar, Cards, Hero, Footer — reads it via <code>useTheme()</code>.
        No prop drilling needed!
      </p>
      <button className={'toggle-btn lg ' + theme} onClick={toggleTheme}>
        {theme === 'light' ? '🌙 Switch to Dark Mode' : '☀️ Switch to Light Mode'}
      </button>

      <div className={'info-box ' + theme}>
        <strong>How it works:</strong>
        <ol>
          <li><code>createContext()</code> — creates the ThemeContext</li>
          <li><code>ThemeProvider</code> — wraps the app, holds <code>useState</code></li>
          <li><code>useTheme()</code> — any component reads the context instantly</li>
        </ol>
      </div>
    </div>
  );
}

function CardGrid() {
  return (
    <div className="card-grid">
      <Card title="🎨 Design" body="The theme context changes the background, text, and border colors of every component simultaneously." />
      <Card title="⚡ Performance" body="Context avoids passing props through many component layers — known as prop drilling." />
      <Card title="🔄 Reactivity" body="When the context value changes, all components that consume it re-render automatically." />
    </div>
  );
}

// ThemeProvider wraps the whole app — all children can access the theme
export default function App() {
  return (
    <ThemeProvider>
      <AppInner />
    </ThemeProvider>
  );
}

function AppInner() {
  const { theme } = useTheme();
  return (
    <div className={'app-wrapper ' + theme}>
      <Navbar />
      <div className="container">
        <Hero />
        <CardGrid />
      </div>
      <Footer />
    </div>
  );
}
