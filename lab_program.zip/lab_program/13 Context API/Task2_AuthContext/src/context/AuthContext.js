import React, { createContext, useContext, useState } from 'react';

// 1. Create AuthContext
const AuthContext = createContext();

// 2. AuthProvider — holds user state and login/logout logic
export function AuthProvider({ children }) {
  const [user, setUser] = useState(null); // null = logged out

  // Simulated login — in real apps this would call an API
  function login(username, password) {
    if (!username || !password) return { success: false, error: 'Both fields required' };
    if (password.length < 4)   return { success: false, error: 'Password must be at least 4 characters' };

    // Simulate user object returned from API
    setUser({
      name:     username,
      email:    username.toLowerCase().replace(' ', '') + '@example.com',
      avatar:   username.charAt(0).toUpperCase(),
      role:     username.toLowerCase() === 'admin' ? 'Admin' : 'User',
      loginTime: new Date().toLocaleTimeString(),
    });
    return { success: true };
  }

  function logout() {
    setUser(null);
  }

  return (
    <AuthContext.Provider value={{ user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

// 3. Custom hook
export function useAuth() {
  return useContext(AuthContext);
}
