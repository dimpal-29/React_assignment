import React from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import Navbar    from './components/Navbar';
import LoginForm from './components/LoginForm';
import Welcome   from './components/Welcome';
import './App.css';

function MainContent() {
  const { user } = useAuth();
  return (
    <div className="container">
      {/* If user is logged in → show Welcome, else → show LoginForm */}
      {user ? <Welcome /> : <LoginForm />}

      <div className="concept-box">
        <h3>📖 How Context API Auth Works</h3>
        <ul>
          <li><code>createContext()</code> — creates the AuthContext</li>
          <li><code>AuthProvider</code> — holds <code>user</code> state + <code>login()</code> / <code>logout()</code></li>
          <li><code>useAuth()</code> — any component reads user state without props</li>
          <li>Navbar, LoginForm, Welcome all share the same user state</li>
        </ul>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <Navbar />
      <MainContent />
    </AuthProvider>
  );
}
