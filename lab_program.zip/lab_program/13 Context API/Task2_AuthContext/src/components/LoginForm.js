import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';

function LoginForm() {
  const { login } = useAuth();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError]       = useState('');

  function handleSubmit() {
    const result = login(username, password);
    if (!result.success) {
      setError(result.error);
    } else {
      setError('');
    }
  }

  return (
    <div className="login-box">
      <div className="login-icon">🔒</div>
      <h2>Please Log In</h2>
      <p className="login-sub">You are not logged in. Enter your credentials to continue.</p>

      {error && <div className="form-error">⚠️ {error}</div>}

      <div className="form-group">
        <label>Username</label>
        <input
          type="text"
          className="inp"
          placeholder="e.g. Admin or Alice"
          value={username}
          onChange={function (e) { setUsername(e.target.value); }}
        />
      </div>
      <div className="form-group">
        <label>Password</label>
        <input
          type="password"
          className="inp"
          placeholder="Min 4 characters"
          value={password}
          onChange={function (e) { setPassword(e.target.value); }}
        />
      </div>
      <button className="btn btn-login" onClick={handleSubmit}>Login →</button>
      <p className="hint">💡 Try username <strong>Admin</strong> for admin role</p>
    </div>
  );
}

export default LoginForm;
