import React from 'react';
import { useAuth } from '../context/AuthContext';

function Welcome() {
  const { user, logout } = useAuth();
  return (
    <div className="welcome-box">
      <div className="welcome-avatar">{user.avatar}</div>
      <h2 className="welcome-title">👋 Welcome, {user.name}!</h2>
      <p className="welcome-sub">You are successfully logged in.</p>

      <div className="user-info-grid">
        <div className="info-item"><span className="info-label">Name</span><span>{user.name}</span></div>
        <div className="info-item"><span className="info-label">Email</span><span>{user.email}</span></div>
        <div className="info-item"><span className="info-label">Role</span><span className={'role-badge ' + user.role.toLowerCase()}>{user.role}</span></div>
        <div className="info-item"><span className="info-label">Logged in at</span><span>{user.loginTime}</span></div>
      </div>

      <div className="explain-box">
        <p>
          This user object is stored in <code>AuthContext</code> and shared across
          <strong> Navbar</strong>, <strong>Welcome</strong>, and any other component —
          without passing any props!
        </p>
      </div>

      <button className="btn btn-logout-main" onClick={logout}>🚪 Logout</button>
    </div>
  );
}

export default Welcome;
