import React from 'react';
import { useAuth } from '../context/AuthContext';

function Navbar() {
  const { user, logout } = useAuth();
  return (
    <nav className="navbar">
      <span className="nav-brand">🔐 AuthApp</span>
      <div className="nav-right">
        {user ? (
          <>
            <span className="nav-welcome">👋 {user.name} ({user.role})</span>
            <button className="btn btn-logout" onClick={logout}>Logout</button>
          </>
        ) : (
          <span className="nav-guest">Not logged in</span>
        )}
      </div>
    </nav>
  );
}

export default Navbar;
