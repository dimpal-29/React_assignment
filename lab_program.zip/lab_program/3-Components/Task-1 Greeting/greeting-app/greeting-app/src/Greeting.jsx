import React from "react";

// Functional Component - accepts "name" as a prop
const Greeting = ({ name }) => {
  return (
    <div style={styles.container}>
      <h1 style={styles.message}>Hello, {name}!</h1>
    </div>
  );
};

const styles = {
  container: {
    maxWidth: "500px",
    margin: "80px auto",
    padding: "40px",
    backgroundColor: "#eaf4fb",
    borderRadius: "12px",
    boxShadow: "0 4px 14px rgba(0,0,0,0.1)",
    fontFamily: "Arial, sans-serif",
    textAlign: "center",
  },
  message: {
    fontSize: "2.2rem",
    color: "#2c3e50",
    margin: 0,
  },
};

export default Greeting;
