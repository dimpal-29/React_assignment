import React from "react";
import Greeting from "./Greeting";

function App() {
  return (
    <div>
      {/* Passing different names as props */}
      <Greeting name="Alice" />
      <Greeting name="Bob" />
      <Greeting name="Charlie" />
    </div>
  );
}

export default App;
