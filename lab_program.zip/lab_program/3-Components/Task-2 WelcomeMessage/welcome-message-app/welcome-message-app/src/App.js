import React from "react";
import WelcomeMessage from "./WelcomeMessage";

function App() {
  return (
    <div>
      {/* Rendering the WelcomeMessage class component */}
      <WelcomeMessage />
    </div>
  );
}

export default App;
