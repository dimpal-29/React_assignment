import React, { Component } from "react";

// Class Component - extends React.Component
class WelcomeMessage extends Component {
  
  // render() method is required in every class component
  render() {
    return (
      <div style={styles.container}>

        {/* Main Heading */}
        <h1 style={styles.heading}>Welcome to React!</h1>

        {/* Description */}
        <p style={styles.paragraph}>
          This message is displayed using a <strong>Class Component</strong>.
        </p>
        <p style={styles.paragraph}>
          Every class component must have a <code style={styles.code}>render()</code> method
          that returns JSX to display on the screen.
        </p>

        {/* Info Box */}
        <div style={styles.infoBox}>
          <p style={styles.infoText}>
            📌 Class Component = <strong>extends Component</strong> + <strong>render()</strong> method
          </p>
        </div>

      </div>
    );
  }
}

// Styles
const styles = {
  container: {
    maxWidth: "560px",
    margin: "60px auto",
    padding: "40px",
    backgroundColor: "#fff8e1",
    borderRadius: "12px",
    boxShadow: "0 4px 14px rgba(0,0,0,0.1)",
    fontFamily: "Arial, sans-serif",
    textAlign: "center",
  },
  heading: {
    fontSize: "2.2rem",
    color: "#e65100",
    marginBottom: "20px",
  },
  paragraph: {
    fontSize: "1rem",
    color: "#444",
    lineHeight: "1.8",
    marginBottom: "12px",
  },
  code: {
    backgroundColor: "#f5f5f5",
    padding: "2px 8px",
    borderRadius: "4px",
    fontFamily: "monospace",
    fontSize: "0.95rem",
    color: "#c0392b",
  },
  infoBox: {
    marginTop: "24px",
    padding: "14px 20px",
    backgroundColor: "#ffe0b2",
    borderRadius: "8px",
    borderLeft: "4px solid #e65100",
  },
  infoText: {
    margin: 0,
    fontSize: "0.95rem",
    color: "#bf360c",
  },
};

export default WelcomeMessage;
