import React from "react";
import LoginLogout from "./LoginLogout";

function App() {
  return (
    <div>
      <LoginLogout />
    </div>
  );
}

export default App;
