import React, { useState } from "react";

const LoginLogout = () => {
  // State to track login status — false = logged out
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  // Event handlers
  const handleLogin  = () => setIsLoggedIn(true);
  const handleLogout = () => setIsLoggedIn(false);

  return (
    <div style={styles.container}>
      <h1 style={styles.title}>Conditional Rendering</h1>

      {/* Status Badge */}
      <div style={{
        ...styles.badge,
        backgroundColor: isLoggedIn ? "#e8f5e9" : "#ffebee",
        border: `2px solid ${isLoggedIn ? "#43a047" : "#e53935"}`,
      }}>
        <span style={{
          ...styles.dot,
          backgroundColor: isLoggedIn ? "#43a047" : "#e53935",
        }} />
        <span style={{ color: isLoggedIn ? "#2e7d32" : "#c62828", fontWeight: "bold" }}>
          {isLoggedIn ? "Status: Logged In" : "Status: Logged Out"}
        </span>
      </div>

      {/* User Info — shown only when logged in */}
      {isLoggedIn && (
        <div style={styles.userCard}>
          <div style={styles.avatar}>U</div>
          <div>
            <p style={styles.userName}>Hello, User!</p>
            <p style={styles.userSub}>Welcome back to your account.</p>
          </div>
        </div>
      )}

      {/* Conditionally show Login or Logout button */}
      {isLoggedIn ? (
        <button style={{ ...styles.button, backgroundColor: "#e53935" }} onClick={handleLogout}>
          🔓 Logout
        </button>
      ) : (
        <button style={{ ...styles.button, backgroundColor: "#43a047" }} onClick={handleLogin}>
          🔒 Login
        </button>
      )}
    </div>
  );
};

const styles = {
  container: {
    maxWidth: "420px",
    margin: "70px auto",
    padding: "40px",
    backgroundColor: "#f5f5ff",
    borderRadius: "14px",
    boxShadow: "0 6px 20px rgba(0,0,0,0.12)",
    fontFamily: "Arial, sans-serif",
    textAlign: "center",
  },
  title: {
    fontSize: "1.5rem",
    color: "#3f51b5",
    marginBottom: "24px",
  },
  badge: {
    display: "inline-flex",
    alignItems: "center",
    gap: "8px",
    padding: "10px 20px",
    borderRadius: "50px",
    marginBottom: "24px",
    fontSize: "0.95rem",
  },
  dot: {
    width: "10px",
    height: "10px",
    borderRadius: "50%",
    display: "inline-block",
  },
  userCard: {
    display: "flex",
    alignItems: "center",
    gap: "14px",
    backgroundColor: "#ffffff",
    borderRadius: "10px",
    padding: "16px 20px",
    marginBottom: "20px",
    boxShadow: "0 2px 8px rgba(0,0,0,0.08)",
    textAlign: "left",
  },
  avatar: {
    width: "48px",
    height: "48px",
    borderRadius: "50%",
    backgroundColor: "#3f51b5",
    color: "#fff",
    fontSize: "1.4rem",
    fontWeight: "bold",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    flexShrink: 0,
  },
  userName: {
    margin: 0,
    fontWeight: "bold",
    fontSize: "1rem",
    color: "#1a1a2e",
  },
  userSub: {
    margin: "4px 0 0",
    fontSize: "0.85rem",
    color: "#777",
  },
  button: {
    padding: "13px 36px",
    fontSize: "1rem",
    color: "#fff",
    border: "none",
    borderRadius: "8px",
    cursor: "pointer",
    fontWeight: "bold",
  },
};

export default LoginLogout;
