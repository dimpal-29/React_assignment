import React from "react";
import VoteEligibility from "./VoteEligibility";

function App() {
  return (
    <div>
      <VoteEligibility />
    </div>
  );
}

export default App;
