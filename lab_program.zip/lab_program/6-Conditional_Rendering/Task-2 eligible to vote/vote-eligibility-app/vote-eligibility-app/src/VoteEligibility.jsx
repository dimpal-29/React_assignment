import React, { useState } from "react";

const VoteEligibility = () => {
  // State to store entered age
  const [age, setAge]       = useState("");
  const [submitted, setSubmitted] = useState(false);

  // Check eligibility
  const isEligible = parseInt(age) >= 18;

  const handleCheck = () => {
    if (age !== "" && parseInt(age) > 0) {
      setSubmitted(true);
    }
  };

  const handleReset = () => {
    setAge("");
    setSubmitted(false);
  };

  return (
    <div style={styles.container}>
      <h1 style={styles.title}>Voting Eligibility Checker</h1>

      {/* Age Input */}
      <div style={styles.formGroup}>
        <label style={styles.label}>Enter Your Age:</label>
        <input
          type="number"
          value={age}
          min="1"
          max="120"
          onChange={(e) => { setAge(e.target.value); setSubmitted(false); }}
          placeholder="e.g. 20"
          style={styles.input}
        />
      </div>

      {/* Check Button */}
      <button style={styles.checkBtn} onClick={handleCheck}>
        ✔ Check Eligibility
      </button>

      {/* Conditional Result — shown after submit */}
      {submitted && age !== "" && (
        <div style={{
          ...styles.resultBox,
          backgroundColor: isEligible ? "#e8f5e9" : "#ffebee",
          border: `2px solid ${isEligible ? "#43a047" : "#e53935"}`,
        }}>
          <p style={styles.resultIcon}>{isEligible ? "yes" : "No"}</p>
          <p style={{
            ...styles.resultText,
            color: isEligible ? "#2e7d32" : "#c62828",
          }}>
            {isEligible
              ? "You are eligible to vote!"
              : "You are not eligible to vote."}
          </p>
          <p style={styles.resultSub}>
            {isEligible
              ? `You are ${age} years old — above the required age of 18.`
              : `You are ${age} years old — minimum required age is 18.`}
          </p>
        </div>
      )}

      {/* Reset */}
      {submitted && (
        <button style={styles.resetBtn} onClick={handleReset}>
          ↺ Check Again
        </button>
      )}
    </div>
  );
};

const styles = {
  container: {
    maxWidth: "440px",
    margin: "70px auto",
    padding: "40px",
    backgroundColor: "#f3f4fb",
    borderRadius: "14px",
    boxShadow: "0 6px 20px rgba(0,0,0,0.12)",
    fontFamily: "Arial, sans-serif",
    textAlign: "center",
  },
  title: {
    fontSize: "1.4rem",
    color: "#3f51b5",
    marginBottom: "28px",
  },
  formGroup: {
    marginBottom: "20px",
    textAlign: "left",
  },
  label: {
    display: "block",
    fontSize: "0.95rem",
    color: "#555",
    fontWeight: "bold",
    marginBottom: "8px",
  },
  input: {
    width: "100%",
    padding: "12px 14px",
    fontSize: "1rem",
    border: "2px solid #c5cae9",
    borderRadius: "8px",
    outline: "none",
    boxSizing: "border-box",
    color: "#333",
    backgroundColor: "#fff",
  },
  checkBtn: {
    padding: "13px 32px",
    fontSize: "1rem",
    backgroundColor: "#3f51b5",
    color: "#fff",
    border: "none",
    borderRadius: "8px",
    cursor: "pointer",
    fontWeight: "bold",
    marginBottom: "22px",
  },
  resultBox: {
    borderRadius: "12px",
    padding: "22px 20px",
    marginBottom: "16px",
  },
  resultIcon: {
    fontSize: "2.4rem",
    margin: "0 0 8px",
  },
  resultText: {
    fontSize: "1.2rem",
    fontWeight: "bold",
    margin: "0 0 8px",
  },
  resultSub: {
    fontSize: "0.88rem",
    color: "#555",
    margin: 0,
  },
  resetBtn: {
    padding: "10px 26px",
    fontSize: "0.95rem",
    backgroundColor: "#757575",
    color: "#fff",
    border: "none",
    borderRadius: "8px",
    cursor: "pointer",
    fontWeight: "bold",
  },
};

export default VoteEligibility;
