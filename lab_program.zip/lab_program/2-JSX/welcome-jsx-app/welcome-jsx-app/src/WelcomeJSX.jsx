import React from "react";

const WelcomeJSX = () => {
  // Dynamic data using variables
  const technology = "JSX";
  const fullForm = "JavaScript XML";
  const framework = "React";
  const author = "Facebook";

  return (
    <div style={styles.container}>
      {/* Heading */}
      <h1 style={styles.heading}>Welcome to JSX</h1>

      {/* Paragraph with dynamic data using curly braces */}
      <p style={styles.paragraph}>
        <strong>{technology}</strong> stands for <em>{fullForm}</em>. It is a
        syntax extension for JavaScript, commonly used with the{" "}
        <strong>{framework}</strong> framework developed by{" "}
        <strong>{author}</strong>. {technology} allows you to write HTML-like
        code inside JavaScript, making UI development easier and more readable.
      </p>

      <p style={styles.paragraph}>
        With {technology}, you can embed any JavaScript expression inside curly
        braces <code>{"{  }"}</code>. For example, the current year is{" "}
        <strong>{new Date().getFullYear()}</strong>.
      </p>
    </div>
  );
};

// Inline styles
const styles = {
  container: {
    maxWidth: "600px",
    margin: "50px auto",
    padding: "30px",
    backgroundColor: "#f0f8ff",
    borderRadius: "10px",
    boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
    fontFamily: "Arial, sans-serif",
  },
  heading: {
    color: "#2c3e50",
    fontSize: "2rem",
    marginBottom: "20px",
    textAlign: "center",
  },
  paragraph: {
    color: "#444",
    fontSize: "1rem",
    lineHeight: "1.8",
    marginBottom: "15px",
  },
};

export default WelcomeJSX;
