import React from 'react';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import Home from './pages/Home';
import About from './pages/About';
import './App.css';

// App.js — Root component
// BrowserRouter  → enables client-side routing using the browser's History API
// Routes         → container that holds all Route definitions
// Route          → maps a URL path to a component
// Link           → renders an <a> tag that navigates without page reload

function App() {
  return (
    <BrowserRouter>
      {/* Simple nav to switch between routes */}
      <nav className="navbar">
        <span className="nav-brand">⚛️ React Router</span>
        <div className="nav-links">
          {/* Link to "/" → renders Home component */}
          <Link to="/" className="nav-link">Home</Link>
          {/* Link to "/about" → renders About component */}
          <Link to="/about" className="nav-link">About</Link>
        </div>
      </nav>

      {/* Routes — only the matching Route is rendered */}
      <Routes>
        <Route path="/"      element={<Home />} />
        <Route path="/about" element={<About />} />
      </Routes>

      <footer className="footer">
        <p>Task 1 — Basic React Router · <code>BrowserRouter</code> + <code>Routes</code> + <code>Route</code></p>
      </footer>
    </BrowserRouter>
  );
}

export default App;
