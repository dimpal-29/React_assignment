import React from 'react';

// Home Page Component
// Displayed when the URL is "/"
function Home() {
  return (
    <div className="page home-page">
      <div className="page-icon">🏠</div>
      <h1 className="page-title">Welcome to the Home Page</h1>
      <p className="page-desc">
        This is the <strong>Home</strong> page. You are currently on the <code>/</code> route.
      </p>
      <div className="info-box">
        <p>
          React Router matched the URL <code>/</code> and rendered this component.
          Change the URL to <code>/about</code> to see the About page.
        </p>
      </div>
      <div className="card-grid">
        <div className="feature-card">
          <span>⚡</span>
          <h3>Fast</h3>
          <p>React renders only what changes</p>
        </div>
        <div className="feature-card">
          <span>🔗</span>
          <h3>Routed</h3>
          <p>React Router handles navigation</p>
        </div>
        <div className="feature-card">
          <span>📦</span>
          <h3>Component-based</h3>
          <p>Each page is its own component</p>
        </div>
      </div>
    </div>
  );
}

export default Home;
