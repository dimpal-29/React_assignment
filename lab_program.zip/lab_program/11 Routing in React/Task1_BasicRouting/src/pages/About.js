import React from 'react';

// About Page Component
// Displayed when the URL is "/about"
function About() {
  return (
    <div className="page about-page">
      <div className="page-icon">ℹ️</div>
      <h1 className="page-title">About Page</h1>
      <p className="page-desc">
        This is the <strong>About</strong> page. You are currently on the <code>/about</code> route.
      </p>
      <div className="info-box">
        <p>
          React Router matched the URL <code>/about</code> and rendered this component
          instead of the Home component — without a full page reload!
        </p>
      </div>
      <div className="about-section">
        <h2>About This App</h2>
        <p>
          This project demonstrates basic <strong>React Router</strong> setup.
          Two routes are defined:
        </p>
        <ul>
          <li><code>/</code> → renders the <strong>Home</strong> component</li>
          <li><code>/about</code> → renders the <strong>About</strong> component</li>
        </ul>
        <p>
          Navigation happens client-side — the browser never does a full page refresh.
          React Router intercepts the URL and swaps the component.
        </p>
      </div>
    </div>
  );
}

export default About;
