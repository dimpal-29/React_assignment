import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home    from './pages/Home';
import About   from './pages/About';
import Contact from './pages/Contact';
import './App.css';

// App.js — Root component
//
// BrowserRouter  → wraps the whole app to enable routing
// Navbar         → always visible; uses NavLink for active highlighting
// Routes         → renders only the matching Route
// Route          → maps each path to a page component

function App() {
  return (
    <BrowserRouter>
      {/* Navbar is outside <Routes> so it shows on every page */}
      <Navbar />

      {/* Only ONE of these routes renders at a time, based on the URL */}
      <Routes>
        <Route path="/"        element={<Home />}    />
        <Route path="/about"   element={<About />}   />
        <Route path="/contact" element={<Contact />} />

        {/* 404 — catches any unknown URL */}
        <Route path="*" element={
          <div className="page not-found">
            <div className="hero-icon">❓</div>
            <h1 className="hero-title">404 — Page Not Found</h1>
            <p className="hero-desc">The URL you visited does not match any route.</p>
          </div>
        } />
      </Routes>

      <footer className="footer">
        <p>Task 2 — React Router · <code>NavLink</code> active highlighting · 3 pages + 404</p>
      </footer>
    </BrowserRouter>
  );
}

export default App;
