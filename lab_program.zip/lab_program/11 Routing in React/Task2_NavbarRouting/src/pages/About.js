import React from 'react';

function About() {
  return (
    <div className="page">
      <div className="hero">
        <div className="hero-icon">ℹ️</div>
        <h1 className="hero-title">About Page</h1>
        <p className="hero-subtitle">
          URL route: <code>/about</code>
        </p>
        <p className="hero-desc">
          This is the <strong>About</strong> page. React Router rendered this component
          because the URL matched the <code>/about</code> route defined in <code>App.js</code>.
        </p>
      </div>

      <div className="content-box">
        <h2>About This Project</h2>
        <p>
          This app demonstrates how to build a <strong>multi-page React application</strong> using
          React Router v6. Key features used:
        </p>
        <ul className="feature-list">
          <li>
            <span className="badge">BrowserRouter</span>
            Wraps the whole app — enables client-side routing
          </li>
          <li>
            <span className="badge">Routes + Route</span>
            Matches the current URL to the right component
          </li>
          <li>
            <span className="badge">NavLink</span>
            Navigation links that highlight when active
          </li>
          <li>
            <span className="badge">Link</span>
            In-page navigation without full page reload
          </li>
        </ul>

        <h2 style={{marginTop: '24px'}}>Team</h2>
        <div className="team-grid">
          {['Alice', 'Bob', 'Charlie'].map(function(name) {
            return (
              <div className="team-card" key={name}>
                <div className="team-avatar">{name.charAt(0)}</div>
                <p className="team-name">{name}</p>
                <p className="team-role">Developer</p>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

export default About;
