import React from 'react';
import { Link } from 'react-router-dom';

function Home() {
  return (
    <div className="page">
      <div className="hero">
        <div className="hero-icon">🏠</div>
        <h1 className="hero-title">Home Page</h1>
        <p className="hero-subtitle">
          URL route: <code>/</code>
        </p>
        <p className="hero-desc">
          Welcome! This is the <strong>Home</strong> page. Use the navigation bar above
          to switch between pages. Notice how the active link is highlighted —
          that is done using React Router's <code>NavLink</code> component.
        </p>
        <div className="hero-btns">
          <Link to="/about"   className="cta-btn">Go to About →</Link>
          <Link to="/contact" className="cta-btn cta-outline">Contact Us →</Link>
        </div>
      </div>

      <div className="cards-row">
        <div className="info-card">
          <h3>🔗 Link</h3>
          <p>Navigates to a route without reloading the page.</p>
          <code>{'<Link to="/about">About</Link>'}</code>
        </div>
        <div className="info-card">
          <h3>✅ NavLink</h3>
          <p>Same as Link but adds an <strong>active</strong> CSS class when the URL matches.</p>
          <code>{'<NavLink to="/about">About</NavLink>'}</code>
        </div>
        <div className="info-card">
          <h3>🗺️ Routes + Route</h3>
          <p>Defines which component to show for each URL path.</p>
          <code>{'<Route path="/about" element={<About />} />'}</code>
        </div>
      </div>
    </div>
  );
}

export default Home;
