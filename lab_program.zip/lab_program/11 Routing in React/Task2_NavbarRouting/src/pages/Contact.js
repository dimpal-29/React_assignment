import React, { useState } from 'react';

function Contact() {
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [submitted, setSubmitted] = useState(false);

  function handleChange(e) {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  }

  function handleSubmit() {
    if (formData.name && formData.email && formData.message) {
      setSubmitted(true);
    }
  }

  function handleReset() {
    setFormData({ name: '', email: '', message: '' });
    setSubmitted(false);
  }

  return (
    <div className="page">
      <div className="hero">
        <div className="hero-icon">📬</div>
        <h1 className="hero-title">Contact Page</h1>
        <p className="hero-subtitle">
          URL route: <code>/contact</code>
        </p>
        <p className="hero-desc">
          This is the <strong>Contact</strong> page — a third route added to show how
          React Router scales to any number of pages.
        </p>
      </div>

      <div className="content-box">
        {submitted ? (
          <div className="success-box">
            <div className="success-icon">✅</div>
            <h2>Message Sent!</h2>
            <p>Thank you, <strong>{formData.name}</strong>! We will get back to you at <strong>{formData.email}</strong> soon.</p>
            <button className="cta-btn" onClick={handleReset}>Send Another</button>
          </div>
        ) : (
          <div className="contact-form">
            <h2>Get in Touch</h2>
            <p>Fill the form below and click Submit.</p>

            <div className="form-group">
              <label>Name</label>
              <input
                type="text"
                name="name"
                placeholder="Your full name"
                value={formData.name}
                onChange={handleChange}
                className="form-input"
              />
            </div>

            <div className="form-group">
              <label>Email</label>
              <input
                type="email"
                name="email"
                placeholder="your@email.com"
                value={formData.email}
                onChange={handleChange}
                className="form-input"
              />
            </div>

            <div className="form-group">
              <label>Message</label>
              <textarea
                name="message"
                placeholder="Write your message here..."
                value={formData.message}
                onChange={handleChange}
                className="form-input form-textarea"
                rows={4}
              />
            </div>

            <button className="cta-btn" onClick={handleSubmit}>
              Send Message →
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

export default Contact;
