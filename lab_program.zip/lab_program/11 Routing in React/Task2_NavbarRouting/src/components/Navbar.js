import React from 'react';
import { NavLink } from 'react-router-dom';
import './Navbar.css';

// Navbar component
// NavLink is like Link but adds an "active" class automatically
// when its URL matches the current route — perfect for navbars

function Navbar() {
  return (
    <nav className="navbar">
      {/* Brand / Logo */}
      <div className="nav-brand">
        <span className="brand-icon">⚛️</span>
        <span className="brand-name">MyApp</span>
      </div>

      {/* Navigation Links */}
      {/* NavLink adds className "active" when the URL matches */}
      <div className="nav-links">
        <NavLink
          to="/"
          end                         /* "end" prevents "/" matching all routes */
          className={function({ isActive }) {
            return 'nav-link' + (isActive ? ' active' : '');
          }}
        >
          🏠 Home
        </NavLink>

        <NavLink
          to="/about"
          className={function({ isActive }) {
            return 'nav-link' + (isActive ? ' active' : '');
          }}
        >
          ℹ️ About
        </NavLink>

        <NavLink
          to="/contact"
          className={function({ isActive }) {
            return 'nav-link' + (isActive ? ' active' : '');
          }}
        >
          📬 Contact
        </NavLink>
      </div>
    </nav>
  );
}

export default Navbar;
