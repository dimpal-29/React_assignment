import React from "react";

// List of users — each user has a unique id
const users = [
  { id: 1, name: "Alice Johnson",  email: "alice@example.com",  role: "Admin",     avatar: "A" },
  { id: 2, name: "Bob Smith",      email: "bob@example.com",    role: "Editor",    avatar: "B" },
  { id: 3, name: "Charlie Lee",    email: "charlie@example.com",role: "Viewer",    avatar: "C" },
  { id: 4, name: "Diana Prince",   email: "diana@example.com",  role: "Admin",     avatar: "D" },
  { id: 5, name: "Edward Norton",  email: "edward@example.com", role: "Editor",    avatar: "E" },
];

// Role badge colors
const roleColors = {
  Admin:  { bg: "#e8eaf6", color: "#3949ab" },
  Editor: { bg: "#e8f5e9", color: "#2e7d32" },
  Viewer: { bg: "#fff3e0", color: "#e65100" },
};

const UserList = () => {
  return (
    <div style={styles.container}>
      <h1 style={styles.title}>👥 User List</h1>
      <p style={styles.subtitle}>
        Each user has a unique <code style={styles.code}>key</code> prop assigned
      </p>

      {/* Render users using map() — key={user.id} is the unique key */}
      {users.map((user) => (
        <div key={user.id} style={styles.card}>

          {/* Avatar */}
          <div style={styles.avatar}>{user.avatar}</div>

          {/* User Info */}
          <div style={styles.info}>
            <div style={styles.nameRow}>
              <span style={styles.name}>{user.name}</span>
              <span style={{
                ...styles.roleBadge,
                backgroundColor: roleColors[user.role].bg,
                color: roleColors[user.role].color,
              }}>
                {user.role}
              </span>
            </div>
            <span style={styles.email}>{user.email}</span>
          </div>

          {/* User ID */}
          <div style={styles.idBadge}>#{user.id}</div>

        </div>
      ))}

      <p style={styles.footer}>Total users: <strong>{users.length}</strong></p>
    </div>
  );
};

const styles = {
  container: {
    maxWidth: "500px",
    margin: "50px auto",
    padding: "36px",
    backgroundColor: "#f3f4fb",
    borderRadius: "14px",
    boxShadow: "0 6px 20px rgba(0,0,0,0.11)",
    fontFamily: "Arial, sans-serif",
  },
  title: {
    fontSize: "1.8rem",
    color: "#3f51b5",
    textAlign: "center",
    marginBottom: "6px",
  },
  subtitle: {
    textAlign: "center",
    fontSize: "0.9rem",
    color: "#777",
    marginBottom: "24px",
  },
  code: {
    backgroundColor: "#f0f0f0",
    padding: "2px 7px",
    borderRadius: "4px",
    fontFamily: "monospace",
    color: "#c0392b",
  },
  card: {
    display: "flex",
    alignItems: "center",
    gap: "14px",
    padding: "14px 16px",
    marginBottom: "12px",
    backgroundColor: "#ffffff",
    borderRadius: "10px",
    boxShadow: "0 2px 8px rgba(0,0,0,0.07)",
  },
  avatar: {
    width: "46px",
    height: "46px",
    borderRadius: "50%",
    backgroundColor: "#3f51b5",
    color: "#fff",
    fontSize: "1.2rem",
    fontWeight: "bold",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    flexShrink: 0,
  },
  info: {
    flex: 1,
    display: "flex",
    flexDirection: "column",
    gap: "4px",
  },
  nameRow: {
    display: "flex",
    alignItems: "center",
    gap: "8px",
    flexWrap: "wrap",
  },
  name: {
    fontWeight: "bold",
    fontSize: "0.97rem",
    color: "#1a1a2e",
  },
  roleBadge: {
    fontSize: "0.75rem",
    fontWeight: "bold",
    padding: "2px 10px",
    borderRadius: "20px",
  },
  email: {
    fontSize: "0.82rem",
    color: "#888",
  },
  idBadge: {
    fontSize: "0.82rem",
    fontWeight: "bold",
    color: "#9e9e9e",
    flexShrink: 0,
  },
  footer: {
    textAlign: "center",
    marginTop: "16px",
    fontSize: "0.9rem",
    color: "#666",
  },
};

export default UserList;
