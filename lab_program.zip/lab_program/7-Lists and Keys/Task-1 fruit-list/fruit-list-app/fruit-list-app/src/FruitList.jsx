import React from "react";

// Array of fruit names
const fruits = [
  " Apple",
  " Banana",
  " Grapes",
  " Orange",
  " Strawberry",
  "Mango",
  " Pineapple",
  " Watermelon",
];

const FruitList = () => {
  return (
    <div style={styles.container}>
      <h1 style={styles.title}> Fruit List</h1>
      <p style={styles.subtitle}>
        Rendered using <code style={styles.code}>map()</code> function
      </p>

      {/* Using map() to render each fruit item */}
      <ul style={styles.list}>
        {fruits.map((fruit, index) => (
          <li key={index} style={styles.listItem}>
            <span style={styles.index}>{index + 1}</span>
            <span style={styles.fruitName}>{fruit}</span>
          </li>
        ))}
      </ul>

      <p style={styles.footer}>Total fruits: <strong>{fruits.length}</strong></p>
    </div>
  );
};

const styles = {
  container: {
    maxWidth: "420px",
    margin: "60px auto",
    padding: "36px",
    backgroundColor: "#f9fbe7",
    borderRadius: "14px",
    boxShadow: "0 6px 20px rgba(0,0,0,0.11)",
    fontFamily: "Arial, sans-serif",
  },
  title: {
    fontSize: "1.8rem",
    color: "#558b2f",
    textAlign: "center",
    marginBottom: "6px",
  },
  subtitle: {
    textAlign: "center",
    fontSize: "0.9rem",
    color: "#777",
    marginBottom: "24px",
  },
  code: {
    backgroundColor: "#f0f0f0",
    padding: "2px 7px",
    borderRadius: "4px",
    fontFamily: "monospace",
    color: "#c0392b",
  },
  list: {
    listStyle: "none",
    padding: 0,
    margin: 0,
  },
  listItem: {
    display: "flex",
    alignItems: "center",
    gap: "14px",
    padding: "12px 16px",
    marginBottom: "10px",
    backgroundColor: "#ffffff",
    borderRadius: "10px",
    boxShadow: "0 2px 6px rgba(0,0,0,0.07)",
    fontSize: "1rem",
    color: "#333",
  },
  index: {
    width: "28px",
    height: "28px",
    borderRadius: "50%",
    backgroundColor: "#aed581",
    color: "#33691e",
    fontWeight: "bold",
    fontSize: "0.85rem",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    flexShrink: 0,
  },
  fruitName: {
    fontSize: "1rem",
    color: "#2e2e2e",
  },
  footer: {
    textAlign: "center",
    marginTop: "18px",
    fontSize: "0.9rem",
    color: "#666",
  },
};

export default FruitList;
