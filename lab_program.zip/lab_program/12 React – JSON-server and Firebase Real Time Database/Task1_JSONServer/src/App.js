import React, { useState, useEffect } from 'react';
import './App.css';

const BASE_URL = 'http://localhost:3001/users';

// ─── Helpers ──────────────────────────────────────────────────────────────────
function apiFetch(url, options) {
  return fetch(url, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  }).then(function (res) {
    if (!res.ok) throw new Error('API error: ' + res.status);
    return res.json();
  });
}

const EMPTY_FORM = { name: '', email: '', city: '', role: 'User' };

// ─── Public API table (JSONPlaceholder) ──────────────────────────────────────
function PublicUsersTable() {
  const [users, setUsers]     = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError]     = useState(null);

  useEffect(function () {
    fetch('https://jsonplaceholder.typicode.com/users')
      .then(function (r) { return r.json(); })
      .then(function (data) { setUsers(data); setLoading(false); })
      .catch(function (e) { setError(e.message); setLoading(false); });
  }, []);

  if (loading) return <div className="spinner-box"><div className="spinner"></div><p>Fetching public API…</p></div>;
  if (error)   return <div className="error-box">❌ {error}</div>;

  return (
    <div className="section">
      <h2 className="section-title">📡 Public API — JSONPlaceholder Users (GET)</h2>
      <div className="table-wrap">
        <table className="table">
          <thead>
            <tr><th>#</th><th>Name</th><th>Email</th><th>City</th><th>Company</th></tr>
          </thead>
          <tbody>
            {users.map(function (u) {
              return (
                <tr key={u.id}>
                  <td>{u.id}</td>
                  <td>{u.name}</td>
                  <td>{u.email}</td>
                  <td>{u.address.city}</td>
                  <td>{u.company.name}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ─── JSON-Server CRUD ─────────────────────────────────────────────────────────
function JSONServerCRUD() {
  const [users, setUsers]       = useState([]);
  const [loading, setLoading]   = useState(true);
  const [form, setForm]         = useState(EMPTY_FORM);
  const [editId, setEditId]     = useState(null);
  const [patchId, setPatchId]   = useState('');
  const [patchRole, setPatchRole] = useState('');
  const [log, setLog]           = useState([]);

  function addLog(msg) {
    setLog(function (prev) { return [msg, ...prev].slice(0, 8); });
  }

  // GET — fetch all users
  function loadUsers() {
    setLoading(true);
    apiFetch(BASE_URL)
      .then(function (data) { setUsers(data); setLoading(false); addLog('GET /users → fetched ' + data.length + ' records'); })
      .catch(function ()    { setLoading(false); addLog('GET failed — is json-server running?'); });
  }

  useEffect(loadUsers, []);

  function handleChange(e) {
    setForm(function (prev) { return { ...prev, [e.target.name]: e.target.value }; });
  }

  // POST — add new user
  function handlePost() {
    if (!form.name || !form.email) return alert('Name and Email are required');
    apiFetch(BASE_URL, { method: 'POST', body: JSON.stringify(form) })
      .then(function (created) {
        setUsers(function (prev) { return [...prev, created]; });
        setForm(EMPTY_FORM);
        addLog('POST /users → created id=' + created.id);
      });
  }

  // PUT — full update
  function handlePut() {
    if (!editId) return;
    apiFetch(BASE_URL + '/' + editId, { method: 'PUT', body: JSON.stringify(form) })
      .then(function (updated) {
        setUsers(function (prev) { return prev.map(function (u) { return u.id === editId ? updated : u; }); });
        setForm(EMPTY_FORM); setEditId(null);
        addLog('PUT /users/' + editId + ' → full update');
      });
  }

  // PATCH — partial update (only role)
  function handlePatch() {
    if (!patchId || !patchRole) return alert('Select user id and new role');
    apiFetch(BASE_URL + '/' + patchId, { method: 'PATCH', body: JSON.stringify({ role: patchRole }) })
      .then(function (updated) {
        setUsers(function (prev) { return prev.map(function (u) { return u.id === Number(patchId) ? updated : u; }); });
        addLog('PATCH /users/' + patchId + ' → role="' + patchRole + '"');
        setPatchId(''); setPatchRole('');
      });
  }

  // DELETE — remove user
  function handleDelete(id) {
    apiFetch(BASE_URL + '/' + id, { method: 'DELETE' })
      .then(function () {
        setUsers(function (prev) { return prev.filter(function (u) { return u.id !== id; }); });
        addLog('DELETE /users/' + id + ' → removed');
      });
  }

  function startEdit(user) {
    setEditId(user.id);
    setForm({ name: user.name, email: user.email, city: user.city, role: user.role });
  }

  return (
    <div className="section">
      <h2 className="section-title">🗄 JSON-Server CRUD — GET · POST · PUT · PATCH · DELETE</h2>
      <div className="server-note">
        ⚠️ Run <code>npm run server</code> in a second terminal before using this section.
        JSON-Server listens at <code>http://localhost:3001</code>
      </div>

      {/* ── Form: POST / PUT ── */}
      <div className="form-card">
        <h3>{editId ? 'Edit User (PUT — full update)' : 'Add User (POST)'}</h3>
        <div className="form-row">
          <input name="name"  placeholder="Name"  value={form.name}  onChange={handleChange} className="inp" />
          <input name="email" placeholder="Email" value={form.email} onChange={handleChange} className="inp" />
          <input name="city"  placeholder="City"  value={form.city}  onChange={handleChange} className="inp" />
          <select name="role" value={form.role} onChange={handleChange} className="inp">
            <option>User</option><option>Admin</option><option>Editor</option>
          </select>
          {editId ? (
            <>
              <button className="btn btn-yellow" onClick={handlePut}>💾 PUT Update</button>
              <button className="btn btn-gray"   onClick={function () { setEditId(null); setForm(EMPTY_FORM); }}>Cancel</button>
            </>
          ) : (
            <button className="btn btn-green" onClick={handlePost}>➕ POST Add</button>
          )}
        </div>
      </div>

      {/* ── PATCH panel ── */}
      <div className="form-card patch-card">
        <h3>PATCH — Partial Update (role only)</h3>
        <div className="form-row">
          <input placeholder="User ID" value={patchId}   onChange={function (e) { setPatchId(e.target.value); }}   className="inp inp-sm" />
          <select value={patchRole} onChange={function (e) { setPatchRole(e.target.value); }} className="inp inp-sm">
            <option value="">Select role</option>
            <option>User</option><option>Admin</option><option>Editor</option>
          </select>
          <button className="btn btn-blue" onClick={handlePatch}>🔧 PATCH Role</button>
        </div>
      </div>

      {/* ── Table ── */}
      {loading ? (
        <div className="spinner-box"><div className="spinner"></div></div>
      ) : (
        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr><th>ID</th><th>Name</th><th>Email</th><th>City</th><th>Role</th><th>Actions</th></tr>
            </thead>
            <tbody>
              {users.map(function (u) {
                return (
                  <tr key={u.id}>
                    <td>{u.id}</td>
                    <td>{u.name}</td>
                    <td>{u.email}</td>
                    <td>{u.city}</td>
                    <td><span className={'badge badge-' + u.role.toLowerCase()}>{u.role}</span></td>
                    <td>
                      <button className="btn-sm btn-edit"   onClick={function () { startEdit(u); }}>✏️ Edit</button>
                      <button className="btn-sm btn-delete" onClick={function () { handleDelete(u.id); }}>🗑 Del</button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* ── API Log ── */}
      <div className="log-box">
        <h4>API Log</h4>
        {log.length === 0 ? <p className="log-empty">No actions yet…</p> : log.map(function (l, i) { return <p key={i} className="log-line">▸ {l}</p>; })}
      </div>
    </div>
  );
}

export default function App() {
  return (
    <div className="app">
      <header className="app-header">
        <h1>⚛️ Task 1 — JSON-Server & Public API</h1>
        <p>Public API (JSONPlaceholder) · JSON-Server CRUD (GET, POST, PUT, PATCH, DELETE)</p>
      </header>
      <PublicUsersTable />
      <JSONServerCRUD />
    </div>
  );
}
