import React, { useState, useEffect } from 'react';
import { auth, googleProvider, database } from './firebase';
import { signInWithPopup, signOut, onAuthStateChanged } from 'firebase/auth';
import { ref, onValue, push, update, remove } from 'firebase/database';
import './App.css';

const EMPTY = { title: '', description: '', status: 'Pending' };

// ─── Google Auth Panel ────────────────────────────────────────────────────────
function AuthPanel({ user, onLogin, onLogout }) {
  return (
    <div className="auth-panel">
      {user ? (
        <div className="auth-user">
          <img src={user.photoURL} alt="avatar" className="avatar" />
          <div>
            <p className="auth-name">👋 {user.displayName}</p>
            <p className="auth-email">{user.email}</p>
          </div>
          <button className="btn btn-red" onClick={onLogout}>Sign Out</button>
        </div>
      ) : (
        <div className="auth-login">
          <p>🔒 Sign in to manage tasks in Firebase Realtime Database</p>
          <button className="btn btn-google" onClick={onLogin}>
            <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" alt="G" width={18} />
            Sign in with Google
          </button>
        </div>
      )}
    </div>
  );
}

// ─── CRUD Table ───────────────────────────────────────────────────────────────
function TasksTable({ user }) {
  const [tasks, setTasks]   = useState([]);
  const [form, setForm]     = useState(EMPTY);
  const [editKey, setEditKey] = useState(null);
  const [loading, setLoading] = useState(true);

  // Real-time listener — onValue fires every time database changes
  useEffect(function () {
    const tasksRef = ref(database, 'tasks');
    const unsub = onValue(tasksRef, function (snapshot) {
      const data = snapshot.val();
      const list = data
        ? Object.entries(data).map(function ([key, val]) { return { key, ...val }; })
        : [];
      setTasks(list);
      setLoading(false);
    });
    return function () { unsub(); };
  }, []);

  function handleChange(e) {
    setForm(function (prev) { return { ...prev, [e.target.name]: e.target.value }; });
  }

  // CREATE — push new record to Firebase
  function handleAdd() {
    if (!form.title) return alert('Title is required');
    push(ref(database, 'tasks'), { ...form, createdBy: user.email });
    setForm(EMPTY);
  }

  // UPDATE — update existing record
  function handleUpdate() {
    if (!editKey) return;
    update(ref(database, 'tasks/' + editKey), form);
    setForm(EMPTY); setEditKey(null);
  }

  // DELETE — remove record from Firebase
  function handleDelete(key) {
    remove(ref(database, 'tasks/' + key));
  }

  function startEdit(task) {
    setEditKey(task.key);
    setForm({ title: task.title, description: task.description, status: task.status });
  }

  if (!user) return <div className="locked-box">🔒 Please sign in to view and manage tasks.</div>;

  return (
    <div className="section">
      <h2 className="section-title">📋 Firebase Realtime Database — CRUD</h2>

      {/* Form */}
      <div className="form-card">
        <h3>{editKey ? 'Edit Task (UPDATE)' : 'Add Task (CREATE)'}</h3>
        <div className="form-row">
          <input name="title"       placeholder="Task title"       value={form.title}       onChange={handleChange} className="inp" />
          <input name="description" placeholder="Description"      value={form.description} onChange={handleChange} className="inp" />
          <select name="status" value={form.status} onChange={handleChange} className="inp">
            <option>Pending</option><option>In Progress</option><option>Done</option>
          </select>
          {editKey ? (
            <>
              <button className="btn btn-yellow" onClick={handleUpdate}>💾 Update</button>
              <button className="btn btn-gray"   onClick={function () { setEditKey(null); setForm(EMPTY); }}>Cancel</button>
            </>
          ) : (
            <button className="btn btn-green" onClick={handleAdd}>➕ Add</button>
          )}
        </div>
      </div>

      {/* Table */}
      {loading ? (
        <div className="spinner-box"><div className="spinner"></div></div>
      ) : tasks.length === 0 ? (
        <p className="empty-msg">No tasks yet. Add one above!</p>
      ) : (
        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr><th>Title</th><th>Description</th><th>Status</th><th>Created By</th><th>Actions</th></tr>
            </thead>
            <tbody>
              {tasks.map(function (t) {
                return (
                  <tr key={t.key}>
                    <td>{t.title}</td>
                    <td>{t.description}</td>
                    <td><span className={'badge badge-' + t.status.replace(' ', '').toLowerCase()}>{t.status}</span></td>
                    <td style={{fontSize:'0.75rem', color:'#718096'}}>{t.createdBy}</td>
                    <td>
                      <button className="btn-sm btn-edit"   onClick={function () { startEdit(t); }}>✏️ Edit</button>
                      <button className="btn-sm btn-delete" onClick={function () { handleDelete(t.key); }}>🗑 Del</button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

// ─── Root App ─────────────────────────────────────────────────────────────────
export default function App() {
  const [user, setUser] = useState(null);

  // Listen for auth state changes
  useEffect(function () {
    return onAuthStateChanged(auth, function (u) { setUser(u); });
  }, []);

  function handleGoogleLogin() {
    signInWithPopup(auth, googleProvider).catch(function (e) { alert(e.message); });
  }

  function handleLogout() {
    signOut(auth);
  }

  return (
    <div className="app">
      <header className="app-header">
        <h1>🔥 Task 2 — Firebase CRUD & Google Authentication</h1>
        <p>Realtime Database (Create, Read, Update, Delete) · Google Sign-In</p>
      </header>

      <div className="setup-note section">
        <h3>⚙️ Setup Required</h3>
        <ol>
          <li>Create a project at <strong>console.firebase.google.com</strong></li>
          <li>Enable <strong>Realtime Database</strong> and <strong>Google Authentication</strong></li>
          <li>Copy your config into <code>src/firebase.js</code></li>
          <li>Run <code>npm install</code> then <code>npm start</code></li>
        </ol>
      </div>

      <AuthPanel user={user} onLogin={handleGoogleLogin} onLogout={handleLogout} />
      <TasksTable user={user} />
    </div>
  );
}
