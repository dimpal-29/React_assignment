// src/firebase.js
// ─────────────────────────────────────────────────────────────────────────────
// HOW TO SET UP FIREBASE:
//
// 1. Go to https://console.firebase.google.com
// 2. Create a new project
// 3. Enable "Realtime Database" (in Build → Realtime Database → Create database)
// 4. Enable "Authentication" → Sign-in method → Google (enable it)
// 5. Go to Project Settings → Your apps → Add web app
// 6. Copy your firebaseConfig values and paste them below
// ─────────────────────────────────────────────────────────────────────────────

import { initializeApp } from 'firebase/app';
import { getDatabase }   from 'firebase/database';
import { getAuth, GoogleAuthProvider } from 'firebase/auth';

// ⚠️ Replace these values with your own Firebase project config
const firebaseConfig = {
  apiKey:            "YOUR_API_KEY",
  authDomain:        "YOUR_AUTH_DOMAIN",
  databaseURL:       "YOUR_DATABASE_URL",
  projectId:         "YOUR_PROJECT_ID",
  storageBucket:     "YOUR_STORAGE_BUCKET",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId:             "YOUR_APP_ID",
};

const app      = initializeApp(firebaseConfig);
const database = getDatabase(app);
const auth     = getAuth(app);
const googleProvider = new GoogleAuthProvider();

export { database, auth, googleProvider };
