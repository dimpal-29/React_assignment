import React, { useState, useEffect } from 'react';
import './App.css';

// ─── Custom hook — handles loading, error, data, and retry ───────────────────
function useFetch(url) {
  const [data, setData]       = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError]     = useState(null);
  const [trigger, setTrigger] = useState(0);   // incrementing this re-runs the effect

  useEffect(function () {
    if (!url) return;
    setLoading(true);
    setError(null);
    setData(null);

    const controller = new AbortController();   // lets us cancel the fetch

    fetch(url, { signal: controller.signal })
      .then(function (res) {
        // Manually check HTTP status — fetch does NOT throw on 4xx/5xx
        if (!res.ok) throw new Error('HTTP ' + res.status + ' — ' + res.statusText);
        return res.json();
      })
      .then(function (json) {
        setData(json);
        setLoading(false);
      })
      .catch(function (err) {
        if (err.name === 'AbortError') return;  // cancelled — ignore
        setError(err.message);
        setLoading(false);
      });

    // Cleanup: cancel in-flight request if component unmounts or url changes
    return function () { controller.abort(); };
  }, [url, trigger]);

  function retry() { setTrigger(function (n) { return n + 1; }); }

  return { data, loading, error, retry };
}

// ─── Loading Spinner component ────────────────────────────────────────────────
function Spinner({ message }) {
  return (
    <div className="spinner-container">
      <div className="spinner-ring">
        <div></div><div></div><div></div><div></div>
      </div>
      <p className="spinner-text">{message || 'Loading…'}</p>
    </div>
  );
}

// ─── Error Display component ──────────────────────────────────────────────────
function ErrorMessage({ message, onRetry }) {
  return (
    <div className="error-container">
      <div className="error-icon">⚠️</div>
      <h3 className="error-title">Something went wrong</h3>
      <p className="error-msg">{message}</p>
      {onRetry && (
        <button className="btn btn-retry" onClick={onRetry}>
          🔄 Retry
        </button>
      )}
    </div>
  );
}

// ─── Demo 1 — Successful fetch ────────────────────────────────────────────────
function SuccessDemo() {
  const { data, loading, error, retry } = useFetch('https://jsonplaceholder.typicode.com/posts?_limit=6');

  return (
    <div className="section">
      <h2 className="section-title">✅ Demo 1 — Successful API Fetch with Loading Spinner</h2>
      <p className="section-desc">Fetches 6 posts from JSONPlaceholder. Shows spinner while loading.</p>

      {loading && <Spinner message="Fetching posts from API…" />}
      {error   && <ErrorMessage message={error} onRetry={retry} />}
      {data && (
        <div className="posts-grid">
          {data.map(function (post) {
            return (
              <div className="post-card" key={post.id}>
                <span className="post-id">#{post.id}</span>
                <h4 className="post-title">{post.title}</h4>
                <p className="post-body">{post.body.slice(0, 80)}…</p>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ─── Demo 2 — Intentional Error ───────────────────────────────────────────────
function ErrorDemo() {
  const { data, loading, error, retry } = useFetch('https://jsonplaceholder.typicode.com/invalid-endpoint-404');

  return (
    <div className="section">
      <h2 className="section-title">❌ Demo 2 — Error State + Retry Button</h2>
      <p className="section-desc">Calls an invalid URL on purpose to demonstrate error handling and the Retry button.</p>

      {loading && <Spinner message="Calling invalid endpoint…" />}
      {error   && <ErrorMessage message={error} onRetry={retry} />}
      {data    && <p className="success-msg">✅ Data received (unexpected!)</p>}
    </div>
  );
}

// ─── Demo 3 — Manual trigger with loading ─────────────────────────────────────
function ManualFetchDemo() {
  const [url, setUrl]         = useState('');
  const [activeUrl, setActive] = useState('');
  const { data, loading, error, retry } = useFetch(activeUrl);

  const PRESETS = [
    { label: 'Users',   url: 'https://jsonplaceholder.typicode.com/users?_limit=4' },
    { label: 'Todos',   url: 'https://jsonplaceholder.typicode.com/todos?_limit=5' },
    { label: 'Bad URL', url: 'https://this-domain-does-not-exist-xyz.com/api' },
  ];

  return (
    <div className="section">
      <h2 className="section-title">🎮 Demo 3 — Manual Fetch with Custom URL</h2>
      <p className="section-desc">Type a URL or pick a preset. See loading and error states in real time.</p>

      <div className="manual-row">
        <input
          className="inp"
          placeholder="Enter any API URL…"
          value={url}
          onChange={function (e) { setUrl(e.target.value); }}
        />
        <button className="btn btn-blue" onClick={function () { setActive(url); }}>Fetch</button>
      </div>
      <div className="preset-row">
        {PRESETS.map(function (p) {
          return (
            <button key={p.label} className="btn btn-preset" onClick={function () { setUrl(p.url); setActive(p.url); }}>
              {p.label}
            </button>
          );
        })}
      </div>

      {loading && <Spinner message="Fetching…" />}
      {error   && <ErrorMessage message={error} onRetry={retry} />}
      {data && !loading && (
        <div className="json-output">
          <pre>{JSON.stringify(Array.isArray(data) ? data.slice(0, 3) : data, null, 2)}</pre>
          <p className="json-note">{Array.isArray(data) ? 'Showing first 3 items of ' + data.length + ' total' : 'Single object'}</p>
        </div>
      )}
    </div>
  );
}

// ─── Root App ─────────────────────────────────────────────────────────────────
export default function App() {
  return (
    <div className="app">
      <header className="app-header">
        <h1>⚛️ Task 3 — Error Handling & Loading States</h1>
        <p>Custom useFetch hook · Loading Spinner · Error Messages · Retry · AbortController</p>
      </header>

      <div className="section concept-box">
        <h2 className="section-title">📖 Concepts Covered</h2>
        <div className="concepts-grid">
          <div className="concept"><strong>Loading State</strong><p>Show spinner while fetch is in-flight</p></div>
          <div className="concept"><strong>Error State</strong><p>Catch HTTP errors & network failures</p></div>
          <div className="concept"><strong>Retry</strong><p>Re-trigger the fetch on user request</p></div>
          <div className="concept"><strong>AbortController</strong><p>Cancel stale requests on unmount</p></div>
          <div className="concept"><strong>res.ok check</strong><p>fetch() doesn't throw on 4xx/5xx</p></div>
          <div className="concept"><strong>Custom Hook</strong><p>useFetch() encapsulates all logic</p></div>
        </div>
      </div>

      <SuccessDemo />
      <ErrorDemo />
      <ManualFetchDemo />
    </div>
  );
}
