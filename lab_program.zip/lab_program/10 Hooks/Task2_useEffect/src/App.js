import React, { useState, useEffect } from 'react';
import './App.css';

function App() {
  const [users, setUsers]     = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError]     = useState(null);

  // useEffect runs after the component mounts (first render)
  // The empty array [] means: run this effect ONLY ONCE on mount
  useEffect(() => {
    fetch('https://jsonplaceholder.typicode.com/users')
      .then(function(response) {
        if (!response.ok) {
          throw new Error('Failed to fetch data');
        }
        return response.json();
      })
      .then(function(data) {
        setUsers(data);
        setLoading(false);
      })
      .catch(function(err) {
        setError(err.message);
        setLoading(false);
      });
  }, []); // <-- [] = run only when component mounts

  return (
    <div className="container">
      <div className="header">
        <h1 className="title">useEffect Hook</h1>
        <p className="subtitle">Task 2 — Fetch API Data on Component Mount</p>
      </div>

      <div className="info-box">
        <code>useEffect(() =&gt; &#123; fetch(...) &#125;, [])</code>
        <span> — runs once when the component mounts and fetches users from JSONPlaceholder API.</span>
      </div>

      {/* Loading state */}
      {loading && (
        <div className="status-box">
          <div className="spinner"></div>
          <p>Loading users from API...</p>
        </div>
      )}

      {/* Error state */}
      {error && (
        <div className="status-box error">
          <p>❌ Error: {error}</p>
        </div>
      )}

      {/* Success — show fetched data */}
      {!loading && !error && (
        <div>
          <p className="count-text">✅ Fetched {users.length} users successfully!</p>
          <div className="grid">
            {users.map(function(user) {
              return (
                <div className="card" key={user.id}>
                  <div className="avatar">{user.name.charAt(0)}</div>
                  <div className="info">
                    <h3 className="user-name">{user.name}</h3>
                    <p className="user-email">📧 {user.email}</p>
                    <p className="user-detail">🏢 {user.company.name}</p>
                    <p className="user-detail">📍 {user.address.city}</p>
                    <p className="user-detail">🌐 {user.website}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
