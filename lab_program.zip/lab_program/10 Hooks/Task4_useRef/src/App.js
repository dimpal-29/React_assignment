import React, { useState, useRef } from 'react';
import './App.css';

// ─── Demo 1: Focus input using useRef ────────────────────────────────────────
function FocusDemo() {
  // useRef creates a reference to the DOM input element
  const inputRef = useRef(null);

  function handleFocus() {
    // Directly access and focus the DOM element — no state needed
    inputRef.current.focus();
  }

  function handleClear() {
    inputRef.current.value = '';
    inputRef.current.focus();
  }

  return (
    <div className="demo-card">
      <h2 className="demo-title">📌 Demo 1 — DOM Reference</h2>
      <p className="demo-desc">
        <code>inputRef = useRef(null)</code> attached to an input.
        Click the button to focus it directly via <code>inputRef.current.focus()</code> — 
        no re-render happens.
      </p>
      <input
        ref={inputRef}
        type="text"
        className="demo-input"
        placeholder="I will be focused by useRef..."
      />
      <div className="btn-row">
        <button className="btn btn-blue" onClick={handleFocus}>
          🎯 Focus Input
        </button>
        <button className="btn btn-gray" onClick={handleClear}>
          🗑 Clear Input
        </button>
      </div>
    </div>
  );
}

// ─── Demo 2: Render counter — useRef vs useState ──────────────────────────────
function RenderCountDemo() {
  const [stateVal, setStateVal] = useState('');

  // useRef to count renders — changing ref.current does NOT cause a re-render
  const renderCount = useRef(0);
  renderCount.current += 1;  // increments every render, silently

  return (
    <div className="demo-card">
      <h2 className="demo-title">🔢 Demo 2 — Render Counter</h2>
      <p className="demo-desc">
        <code>renderCount = useRef(0)</code> tracks how many times this component 
        re-renders. Updating <code>ref.current</code> does NOT cause a re-render.
        Type in the box to trigger re-renders via <code>useState</code>.
      </p>

      <div className="render-badge">
        This component has rendered <strong>{renderCount.current}</strong> time(s)
      </div>

      <input
        type="text"
        className="demo-input"
        placeholder="Type here to cause re-renders..."
        value={stateVal}
        onChange={function(e) { setStateVal(e.target.value); }}
      />
      <p className="hint">
        ↑ Every keystroke updates <code>useState</code> → re-render → render count increases.
      </p>
    </div>
  );
}

// ─── Demo 3: Stopwatch — useRef stores interval ID ───────────────────────────
function StopwatchDemo() {
  const [time, setTime]       = useState(0);
  const [running, setRunning] = useState(false);

  // useRef stores the interval ID between renders WITHOUT triggering re-renders
  const intervalRef = useRef(null);

  function start() {
    if (running) return;
    setRunning(true);
    intervalRef.current = setInterval(function() {
      setTime(function(prev) { return prev + 1; });
    }, 1000);
  }

  function stop() {
    clearInterval(intervalRef.current);
    intervalRef.current = null;
    setRunning(false);
  }

  function reset() {
    clearInterval(intervalRef.current);
    intervalRef.current = null;
    setRunning(false);
    setTime(0);
  }

  var minutes = String(Math.floor(time / 60)).padStart(2, '0');
  var seconds = String(time % 60).padStart(2, '0');

  return (
    <div className="demo-card">
      <h2 className="demo-title">⏱ Demo 3 — Stopwatch (intervalRef)</h2>
      <p className="demo-desc">
        <code>intervalRef = useRef(null)</code> stores the <code>setInterval</code> ID.
        Updating <code>intervalRef.current</code> never causes a re-render — 
        it just quietly holds the value between renders.
      </p>

      <div className="timer-display">
        {minutes}:{seconds}
      </div>

      <div className="btn-row">
        <button className="btn btn-green" onClick={start} disabled={running}>
          ▶ Start
        </button>
        <button className="btn btn-red" onClick={stop} disabled={!running}>
          ⏸ Stop
        </button>
        <button className="btn btn-gray" onClick={reset}>
          ↺ Reset
        </button>
      </div>

      <p className="hint">
        The interval ID is saved in <code>intervalRef.current</code> so 
        <code> clearInterval()</code> can stop it later.
      </p>
    </div>
  );
}

// ─── Demo 4: Previous value tracker ──────────────────────────────────────────
function PreviousValueDemo() {
  const [name, setName] = useState('');

  // Store the previous value of "name" using useRef
  const prevNameRef = useRef('');

  // After render, update the ref to the current value
  // Next render, ref.current will hold the OLD value
  var previousName = prevNameRef.current;
  prevNameRef.current = name;

  return (
    <div className="demo-card">
      <h2 className="demo-title">🔁 Demo 4 — Previous Value</h2>
      <p className="demo-desc">
        <code>prevNameRef.current</code> stores the value from the <em>previous render</em>.
        Because updating a ref does not re-render, it always holds the last render's value.
      </p>

      <input
        type="text"
        className="demo-input"
        placeholder="Type your name..."
        value={name}
        onChange={function(e) { setName(e.target.value); }}
      />

      <div className="value-row">
        <div className="value-box current">
          <span className="value-label">Current</span>
          <span className="value-text">{name || '—'}</span>
        </div>
        <div className="value-box previous">
          <span className="value-label">Previous (via useRef)</span>
          <span className="value-text">{previousName || '—'}</span>
        </div>
      </div>
    </div>
  );
}

// ─── Main App ─────────────────────────────────────────────────────────────────
function App() {
  return (
    <div className="container">
      <div className="page-header">
        <h1 className="page-title">useRef Hook</h1>
        <p className="page-subtitle">Task 4 — Avoid Re-renders in React</p>
      </div>

      <div className="info-box">
        <strong>Key Rule:</strong> Changing <code>ref.current</code> does <strong>NOT</strong> trigger
        a re-render. Use <code>useRef</code> to store DOM references, mutable values, and interval IDs.
      </div>

      <div className="demos-grid">
        <FocusDemo />
        <RenderCountDemo />
        <StopwatchDemo />
        <PreviousValueDemo />
      </div>
    </div>
  );
}

export default App;
