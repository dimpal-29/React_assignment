import React, { useState } from 'react';
import './App.css';

function App() {
  // useState hook — stores the counter value
  // count      → current value
  // setCount   → function to update the value
  const [count, setCount] = useState(0);

  const increment = () => setCount(count + 1);
  const decrement = () => setCount(count - 1);
  const reset     = () => setCount(0);

  return (
    <div className="container">
      <div className="card">
        <h1 className="title">useState Hook</h1>
        <p className="subtitle">Task 1 — Counter App</p>

        {/* Display current count */}
        <div className="counter-box">
          <span className={
            'count ' +
            (count > 0 ? 'positive' : count < 0 ? 'negative' : '')
          }>
            {count}
          </span>
        </div>

        {/* Buttons to update state */}
        <div className="btn-group">
          <button className="btn btn-decrement" onClick={decrement}>
            − Decrement
          </button>
          <button className="btn btn-reset" onClick={reset}>
            Reset
          </button>
          <button className="btn btn-increment" onClick={increment}>
            + Increment
          </button>
        </div>

        {/* Explanation */}
        <div className="info-box">
          <p><strong>How useState works:</strong></p>
          <p>
            <code>const [count, setCount] = useState(0);</code>
          </p>
          <p>
            Every time you click a button, <code>setCount()</code> updates the
            state and React automatically re-renders the component with the
            new value.
          </p>
        </div>
      </div>
    </div>
  );
}

export default App;
