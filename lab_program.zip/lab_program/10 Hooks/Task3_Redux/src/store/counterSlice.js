// src/store/counterSlice.js
import { createSlice } from '@reduxjs/toolkit';

const counterSlice = createSlice({
  name: 'counter',
  initialState: {
    value: 0,
    history: [],
  },
  reducers: {
    // Action: increment
    increment: function(state) {
      state.value += 1;
      state.history.push('Incremented to ' + state.value);
    },
    // Action: decrement
    decrement: function(state) {
      state.value -= 1;
      state.history.push('Decremented to ' + state.value);
    },
    // Action: increment by a custom amount
    incrementByAmount: function(state, action) {
      state.value += action.payload;
      state.history.push('Added ' + action.payload + ' → now ' + state.value);
    },
    // Action: reset
    reset: function(state) {
      state.value = 0;
      state.history.push('Reset to 0');
    },
    // Action: clear history
    clearHistory: function(state) {
      state.history = [];
    },
  },
});

export const { increment, decrement, incrementByAmount, reset, clearHistory } = counterSlice.actions;
export default counterSlice.reducer;
