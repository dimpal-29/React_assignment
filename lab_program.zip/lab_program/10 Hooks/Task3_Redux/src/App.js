import React, { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import {
  increment,
  decrement,
  incrementByAmount,
  reset,
  clearHistory,
} from './store/counterSlice';
import './App.css';

function App() {
  // useSelector — reads data FROM the Redux store
  const count   = useSelector(function(state) { return state.counter.value; });
  const history = useSelector(function(state) { return state.counter.history; });

  // useDispatch — returns dispatch() to SEND actions to the store
  const dispatch = useDispatch();

  const [amount, setAmount] = useState(5);

  return (
    <div className="container">
      <div className="card">
        <h1 className="title">Redux Counter</h1>
        <p className="subtitle">Task 3 — useSelector & useDispatch</p>

        {/* Counter display — reads from store via useSelector */}
        <div className="counter-box">
          <p className="counter-label">Current Value (from Redux store)</p>
          <span className={'count ' + (count > 0 ? 'positive' : count < 0 ? 'negative' : '')}>
            {count}
          </span>
        </div>

        {/* Basic action buttons — dispatch actions to the store */}
        <div className="btn-group">
          <button className="btn btn-red"   onClick={function() { dispatch(decrement()); }}>
            − Decrement
          </button>
          <button className="btn btn-gray"  onClick={function() { dispatch(reset()); }}>
            Reset
          </button>
          <button className="btn btn-green" onClick={function() { dispatch(increment()); }}>
            + Increment
          </button>
        </div>

        {/* Increment by custom amount */}
        <div className="amount-row">
          <label>Custom Amount:</label>
          <input
            type="number"
            value={amount}
            onChange={function(e) { setAmount(Number(e.target.value)); }}
            className="amount-input"
          />
          <button
            className="btn btn-blue"
            onClick={function() { dispatch(incrementByAmount(amount)); }}
          >
            Add {amount}
          </button>
        </div>

        {/* Action History */}
        <div className="history-box">
          <div className="history-header">
            <h3>Action History</h3>
            {history.length > 0 && (
              <button
                className="btn-clear"
                onClick={function() { dispatch(clearHistory()); }}
              >
                Clear
              </button>
            )}
          </div>
          {history.length === 0 ? (
            <p className="empty">No actions dispatched yet.</p>
          ) : (
            <ul className="history-list">
              {history.map(function(item, index) {
                return <li key={index}>• {item}</li>;
              })}
            </ul>
          )}
        </div>

        {/* Explanation */}
        <div className="info-box">
          <p><strong>useSelector</strong> — reads <code>state.counter.value</code> from the Redux store.</p>
          <p><strong>useDispatch</strong> — calls <code>dispatch(increment())</code> to send an action to the reducer.</p>
          <p>The Redux store is the <strong>single source of truth</strong> for the whole app.</p>
        </div>
      </div>
    </div>
  );
}

export default App;
