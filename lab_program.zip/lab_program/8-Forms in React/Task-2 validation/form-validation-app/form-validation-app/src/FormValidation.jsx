import React, { useState } from "react";

const FormValidation = () => {
  // Form data state
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
  });

  // Errors state — one error message per field
  const [errors, setErrors] = useState({});

  // Submitted data state
  const [submittedData, setSubmittedData] = useState(null);

  // ─── Validation Rules ────────────────────────────────────────────
  const validate = (data) => {
    const newErrors = {};

    // Name validation
    if (!data.name.trim()) {
      newErrors.name = " Name is required.";
    } else if (data.name.trim().length < 3) {
      newErrors.name = " Name must be at least 3 characters.";
    }

    // Email validation — checks format using regex
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!data.email.trim()) {
      newErrors.email = " Email is required.";
    } else if (!emailRegex.test(data.email)) {
      newErrors.email = " Enter a valid email (e.g. user@example.com).";
    }

    // Password validation
    if (!data.password) {
      newErrors.password = " Password is required.";
    } else if (data.password.length < 6) {
      newErrors.password = "Password must be at least 6 characters.";
    } else if (!/[A-Z]/.test(data.password)) {
      newErrors.password = " Password must contain at least one uppercase letter.";
    } else if (!/[0-9]/.test(data.password)) {
      newErrors.password = " Password must contain at least one number.";
    }

    return newErrors;
  };

  // Handle input change — also clears error for that field live
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));

    // Live clear error when user starts fixing
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: "" }));
    }
  };

  // Handle submit
  const handleSubmit = (e) => {
    e.preventDefault();
    const validationErrors = validate(formData);

    if (Object.keys(validationErrors).length > 0) {
      // Show errors — do NOT submit
      setErrors(validationErrors);
    } else {
      // All valid — submit
      setErrors({});
      setSubmittedData({ ...formData });
    }
  };

  // Reset everything
  const handleReset = () => {
    setFormData({ name: "", email: "", password: "" });
    setErrors({});
    setSubmittedData(null);
  };

  // Helper — input border color based on error state
  const borderColor = (field) => {
    if (errors[field]) return "#e53935";
    if (formData[field] && !errors[field]) return "#43a047";
    return "#c5cae9";
  };

  return (
    <div style={styles.page}>
      <div style={styles.container}>
        <h1 style={styles.title}>🔐 Form with Validation</h1>
        <p style={styles.subtitle}>All fields are validated before submit</p>

        <form onSubmit={handleSubmit} noValidate style={styles.form}>

          {/* ── Name Field ── */}
          <div style={styles.formGroup}>
            <label style={styles.label}>Full Name</label>
            <input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleChange}
              placeholder="Enter your name"
              style={{ ...styles.input, borderColor: borderColor("name") }}
            />
            {errors.name && <p style={styles.errorMsg}>{errors.name}</p>}
            {!errors.name && formData.name.trim().length >= 3 && (
              <p style={styles.successMsg}> Name looks good!</p>
            )}
          </div>

          {/* ── Email Field ── */}
          <div style={styles.formGroup}>
            <label style={styles.label}>Email Address</label>
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="Enter your email"
              style={{ ...styles.input, borderColor: borderColor("email") }}
            />
            {errors.email && <p style={styles.errorMsg}>{errors.email}</p>}
            {!errors.email && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email) && (
              <p style={styles.successMsg}> Valid email address!</p>
            )}
          </div>

          {/* ── Password Field ── */}
          <div style={styles.formGroup}>
            <label style={styles.label}>Password</label>
            <input
              type="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              placeholder="Min 6 chars, 1 uppercase, 1 number"
              style={{ ...styles.input, borderColor: borderColor("password") }}
            />
            {errors.password && <p style={styles.errorMsg}>{errors.password}</p>}
            {!errors.password && formData.password.length >= 6 &&
              /[A-Z]/.test(formData.password) && /[0-9]/.test(formData.password) && (
              <p style={styles.successMsg}> Strong password!</p>
            )}

            {/* Password strength hints */}
            {formData.password && (
              <ul style={styles.hintList}>
                <li style={{ color: formData.password.length >= 6 ? "#43a047" : "#999" }}>
                  {formData.password.length >= 6 ? "✔" : "○"} At least 6 characters
                </li>
                <li style={{ color: /[A-Z]/.test(formData.password) ? "#43a047" : "#999" }}>
                  {/[A-Z]/.test(formData.password) ? "✔" : "○"} One uppercase letter
                </li>
                <li style={{ color: /[0-9]/.test(formData.password) ? "#43a047" : "#999" }}>
                  {/[0-9]/.test(formData.password) ? "✔" : "○"} One number
                </li>
              </ul>
            )}
          </div>

          {/* Submit */}
          <button type="submit" style={styles.submitBtn}>
            🚀 Submit Form
          </button>
        </form>

        {/* Success Result */}
        {submittedData && (
          <div style={styles.resultBox}>
            <h3 style={styles.resultTitle}> Form Submitted Successfully!</h3>
            <div style={styles.resultRow}>
              <span style={styles.resultLabel}>Name:</span>
              <span style={styles.resultValue}>{submittedData.name}</span>
            </div>
            <div style={styles.resultRow}>
              <span style={styles.resultLabel}>Email:</span>
              <span style={styles.resultValue}>{submittedData.email}</span>
            </div>
            <div style={styles.resultRow}>
              <span style={styles.resultLabel}>Password:</span>
              <span style={styles.resultValue}>{"•".repeat(submittedData.password.length)}</span>
            </div>
            <button onClick={handleReset} style={styles.resetBtn}>↺ Reset Form</button>
          </div>
        )}
      </div>
    </div>
  );
};

const styles = {
  page: {
    minHeight: "100vh",
    backgroundColor: "#fce4ec",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    padding: "40px 20px",
    boxSizing: "border-box",
  },
  container: {
    width: "100%",
    maxWidth: "460px",
    backgroundColor: "#ffffff",
    borderRadius: "16px",
    boxShadow: "0 8px 24px rgba(0,0,0,0.12)",
    padding: "40px 36px",
    fontFamily: "Arial, sans-serif",
  },
  title: {
    fontSize: "1.6rem",
    color: "#c2185b",
    textAlign: "center",
    marginBottom: "6px",
  },
  subtitle: {
    textAlign: "center",
    fontSize: "0.88rem",
    color: "#999",
    marginBottom: "28px",
  },
  form: {
    display: "flex",
    flexDirection: "column",
    gap: "18px",
  },
  formGroup: {
    display: "flex",
    flexDirection: "column",
    gap: "5px",
  },
  label: {
    fontSize: "0.9rem",
    fontWeight: "bold",
    color: "#444",
  },
  input: {
    padding: "12px 14px",
    fontSize: "0.97rem",
    border: "2px solid #c5cae9",
    borderRadius: "8px",
    outline: "none",
    color: "#333",
    backgroundColor: "#fafafa",
    boxSizing: "border-box",
    width: "100%",
    transition: "border-color 0.2s",
  },
  errorMsg: {
    margin: 0,
    fontSize: "0.82rem",
    color: "#e53935",
  },
  successMsg: {
    margin: 0,
    fontSize: "0.82rem",
    color: "#2e7d32",
  },
  hintList: {
    margin: "6px 0 0",
    padding: "0 0 0 16px",
    fontSize: "0.8rem",
    lineHeight: "1.8",
  },
  submitBtn: {
    marginTop: "6px",
    padding: "13px",
    fontSize: "1rem",
    backgroundColor: "#c2185b",
    color: "#fff",
    border: "none",
    borderRadius: "8px",
    cursor: "pointer",
    fontWeight: "bold",
  },
  resultBox: {
    marginTop: "28px",
    padding: "20px 22px",
    backgroundColor: "#e8f5e9",
    border: "2px solid #43a047",
    borderRadius: "12px",
  },
  resultTitle: {
    fontSize: "1rem",
    color: "#2e7d32",
    marginBottom: "14px",
    textAlign: "center",
  },
  resultRow: {
    display: "flex",
    justifyContent: "space-between",
    padding: "8px 0",
    borderBottom: "1px solid #c8e6c9",
    fontSize: "0.93rem",
  },
  resultLabel: {
    color: "#555",
    fontWeight: "bold",
  },
  resultValue: {
    color: "#1b5e20",
    fontWeight: "bold",
    wordBreak: "break-all",
  },
  resetBtn: {
    marginTop: "16px",
    width: "100%",
    padding: "10px",
    fontSize: "0.93rem",
    backgroundColor: "#757575",
    color: "#fff",
    border: "none",
    borderRadius: "8px",
    cursor: "pointer",
    fontWeight: "bold",
  },
};

export default FormValidation;
