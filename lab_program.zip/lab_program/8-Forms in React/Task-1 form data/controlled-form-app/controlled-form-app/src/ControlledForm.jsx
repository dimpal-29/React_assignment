import React, { useState } from "react";

const ControlledForm = () => {
  // State for each input field
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
  });

  // State to store submitted data
  const [submittedData, setSubmittedData] = useState(null);

  // Single handler for all inputs — updates the correct field by name
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  // Handle form submit
  const handleSubmit = (e) => {
    e.preventDefault(); // Prevent page reload
    setSubmittedData({ ...formData });
  };

  // Reset form
  const handleReset = () => {
    setFormData({ name: "", email: "", password: "" });
    setSubmittedData(null);
  };

  return (
    <div style={styles.page}>
      <div style={styles.container}>
        <h1 style={styles.title}> Controlled Form</h1>
        <p style={styles.subtitle}>
          State controls every input field
        </p>

        <form onSubmit={handleSubmit} style={styles.form}>

          {/* Name Field */}
          <div style={styles.formGroup}>
            <label style={styles.label}>Full Name</label>
            <input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleChange}
              placeholder="Enter your name"
              style={styles.input}
              required
            />
          </div>

          {/* Email Field */}
          <div style={styles.formGroup}>
            <label style={styles.label}>Email Address</label>
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="Enter your email"
              style={styles.input}
              required
            />
          </div>

          {/* Password Field */}
          <div style={styles.formGroup}>
            <label style={styles.label}>Password</label>
            <input
              type="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              placeholder="Enter your password"
              style={styles.input}
              required
            />
          </div>

          {/* Submit Button */}
          <button type="submit" style={styles.submitBtn}>
             Submit Form
          </button>
        </form>

        {/* Display submitted data */}
        {submittedData && (
          <div style={styles.resultBox}>
            <h3 style={styles.resultTitle}> Form Submitted Successfully!</h3>
            <div style={styles.resultRow}>
              <span style={styles.resultLabel}>Name:</span>
              <span style={styles.resultValue}>{submittedData.name}</span>
            </div>
            <div style={styles.resultRow}>
              <span style={styles.resultLabel}>Email:</span>
              <span style={styles.resultValue}>{submittedData.email}</span>
            </div>
            <div style={styles.resultRow}>
              <span style={styles.resultLabel}>Password:</span>
              <span style={styles.resultValue}>{"•".repeat(submittedData.password.length)}</span>
            </div>
            <button onClick={handleReset} style={styles.resetBtn}>
              ↺ Reset Form
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

const styles = {
  page: {
    minHeight: "100vh",
    backgroundColor: "#eef2ff",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    padding: "40px 20px",
    boxSizing: "border-box",
  },
  container: {
    width: "100%",
    maxWidth: "460px",
    backgroundColor: "#ffffff",
    borderRadius: "16px",
    boxShadow: "0 8px 24px rgba(0,0,0,0.12)",
    padding: "40px 36px",
    fontFamily: "Arial, sans-serif",
  },
  title: {
    fontSize: "1.6rem",
    color: "#3f51b5",
    textAlign: "center",
    marginBottom: "6px",
  },
  subtitle: {
    textAlign: "center",
    fontSize: "0.88rem",
    color: "#999",
    marginBottom: "28px",
  },
  form: {
    display: "flex",
    flexDirection: "column",
    gap: "18px",
  },
  formGroup: {
    display: "flex",
    flexDirection: "column",
    gap: "6px",
  },
  label: {
    fontSize: "0.9rem",
    fontWeight: "bold",
    color: "#444",
  },
  input: {
    padding: "12px 14px",
    fontSize: "0.97rem",
    border: "2px solid #c5cae9",
    borderRadius: "8px",
    outline: "none",
    color: "#333",
    backgroundColor: "#fafafa",
    boxSizing: "border-box",
    width: "100%",
  },
  submitBtn: {
    marginTop: "6px",
    padding: "13px",
    fontSize: "1rem",
    backgroundColor: "#3f51b5",
    color: "#fff",
    border: "none",
    borderRadius: "8px",
    cursor: "pointer",
    fontWeight: "bold",
  },
  resultBox: {
    marginTop: "28px",
    padding: "20px 22px",
    backgroundColor: "#e8f5e9",
    border: "2px solid #43a047",
    borderRadius: "12px",
  },
  resultTitle: {
    fontSize: "1rem",
    color: "#2e7d32",
    marginBottom: "14px",
    textAlign: "center",
  },
  resultRow: {
    display: "flex",
    justifyContent: "space-between",
    padding: "8px 0",
    borderBottom: "1px solid #c8e6c9",
    fontSize: "0.93rem",
  },
  resultLabel: {
    color: "#555",
    fontWeight: "bold",
  },
  resultValue: {
    color: "#1b5e20",
    fontWeight: "bold",
    wordBreak: "break-all",
  },
  resetBtn: {
    marginTop: "16px",
    width: "100%",
    padding: "10px",
    fontSize: "0.93rem",
    backgroundColor: "#757575",
    color: "#fff",
    border: "none",
    borderRadius: "8px",
    cursor: "pointer",
    fontWeight: "bold",
  },
};

export default ControlledForm;
