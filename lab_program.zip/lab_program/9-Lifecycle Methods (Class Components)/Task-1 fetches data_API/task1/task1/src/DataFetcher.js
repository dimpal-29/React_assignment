import React, { Component } from "react";

class DataFetcher extends Component {
  constructor(props) {
    super(props);
    this.state = {
      users: [],
      loading: true,
      error: null,
    };
  }

  componentDidMount() {
    fetch("https://jsonplaceholder.typicode.com/users")
      .then((response) => {
        if (!response.ok) {
          throw new Error("Failed to fetch data from API.");
        }
        return response.json();
      })
      .then((data) => {
        this.setState({ users: data, loading: false });
      })
      .catch((error) => {
        this.setState({ error: error.message, loading: false });
      });
  }

  render() {
    const { users, loading, error } = this.state;

    if (loading) {
      return (
        <div style={styles.centered}>
          <p style={styles.loading}>Loading data from API...</p>
        </div>
      );
    }

    if (error) {
      return (
        <div style={styles.centered}>
          <p style={styles.error}>Error: {error}</p>
        </div>
      );
    }

    return (
      <div style={styles.container}>
        <h1 style={styles.title}>Task 1 - componentDidMount API Fetch</h1>
        <p style={styles.info}>
          Data fetched from{" "}
          <strong>https://jsonplaceholder.typicode.com/users</strong> using{" "}
          <code>componentDidMount()</code>. Total users: {users.length}
        </p>

        <table style={styles.table}>
          <thead>
            <tr style={styles.headerRow}>
              <th style={styles.th}>ID</th>
              <th style={styles.th}>Name</th>
              <th style={styles.th}>Username</th>
              <th style={styles.th}>Email</th>
              <th style={styles.th}>Phone</th>
              <th style={styles.th}>City</th>
            </tr>
          </thead>
          <tbody>
            {users.map((user, index) => (
              <tr
                key={user.id}
                style={{
                  ...styles.row,
                  backgroundColor: index % 2 === 0 ? "#ffffff" : "#f2f6fb",
                }}
              >
                <td style={styles.td}>{user.id}</td>
                <td style={styles.td}>{user.name}</td>
                <td style={styles.td}>{user.username}</td>
                <td style={styles.td}>{user.email}</td>
                <td style={styles.td}>{user.phone}</td>
                <td style={styles.td}>{user.address.city}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  }
}

const styles = {
  container: {
    maxWidth: "960px",
    margin: "30px auto",
    padding: "24px",
    fontFamily: "Arial, sans-serif",
  },
  centered: {
    textAlign: "center",
    marginTop: "80px",
    fontFamily: "Arial, sans-serif",
  },
  title: {
    fontSize: "26px",
    color: "#2c3e50",
    marginBottom: "10px",
  },
  info: {
    fontSize: "14px",
    color: "#555",
    marginBottom: "20px",
  },
  loading: {
    fontSize: "18px",
    color: "#3498db",
  },
  error: {
    fontSize: "18px",
    color: "#e74c3c",
  },
  table: {
    width: "100%",
    borderCollapse: "collapse",
    boxShadow: "0 2px 8px rgba(0,0,0,0.1)",
    borderRadius: "8px",
    overflow: "hidden",
  },
  headerRow: {
    backgroundColor: "#2c3e50",
  },
  th: {
    padding: "12px 14px",
    color: "#ffffff",
    textAlign: "left",
    fontSize: "14px",
    fontWeight: "bold",
  },
  row: {
    borderBottom: "1px solid #dce3ea",
  },
  td: {
    padding: "11px 14px",
    fontSize: "13px",
    color: "#333",
  },
};

export default DataFetcher;
