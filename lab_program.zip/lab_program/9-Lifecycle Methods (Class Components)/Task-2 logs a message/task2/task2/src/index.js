import React, { Component } from "react";
import ReactDOM from "react-dom/client";
import LifecycleLogger from "./LifecycleLogger";

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showComponent: true,
    };
  }

  toggleComponent = () => {
    this.setState((prev) => ({ showComponent: !prev.showComponent }));
  };

  render() {
    return (
      <div style={styles.wrapper}>
        <h1 style={styles.appTitle}>Task 2 - componentDidUpdate and componentWillUnmount</h1>
        <p style={styles.appNote}>
          Open browser Console (F12) to see lifecycle log messages.
        </p>
        <button style={styles.toggleBtn} onClick={this.toggleComponent}>
          {this.state.showComponent
            ? "Unmount Component (triggers componentWillUnmount)"
            : "Mount Component Again"}
        </button>
        {this.state.showComponent && <LifecycleLogger />}
      </div>
    );
  }
}

const styles = {
  wrapper: {
    maxWidth: "700px",
    margin: "30px auto",
    fontFamily: "Arial, sans-serif",
    padding: "20px",
  },
  appTitle: {
    fontSize: "24px",
    color: "#2c3e50",
    marginBottom: "8px",
  },
  appNote: {
    fontSize: "14px",
    color: "#7f8c8d",
    marginBottom: "16px",
  },
  toggleBtn: {
    padding: "10px 20px",
    backgroundColor: "#8e44ad",
    color: "#fff",
    border: "none",
    borderRadius: "5px",
    cursor: "pointer",
    fontSize: "14px",
    marginBottom: "24px",
  },
};

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />);
