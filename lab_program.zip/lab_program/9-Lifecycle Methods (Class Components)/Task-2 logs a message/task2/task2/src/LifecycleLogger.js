import React, { Component } from "react";

class LifecycleLogger extends Component {
  constructor(props) {
    super(props);
    this.state = {
      count: 0,
      inputText: "",
    };
  }

  componentDidUpdate(prevProps, prevState) {
    if (prevState.count !== this.state.count) {
      console.log(
        "componentDidUpdate() called - Count updated to: " + this.state.count
      );
    }
    if (prevState.inputText !== this.state.inputText) {
      console.log(
        "componentDidUpdate() called - Input changed to: \"" +
          this.state.inputText +
          "\""
      );
    }
  }

  componentWillUnmount() {
    console.log(
      "componentWillUnmount() called - LifecycleLogger has been removed from the DOM."
    );
  }

  handleIncrement = () => {
    this.setState((prev) => ({ count: prev.count + 1 }));
  };

  handleDecrement = () => {
    this.setState((prev) => ({ count: prev.count - 1 }));
  };

  handleInputChange = (e) => {
    this.setState({ inputText: e.target.value });
  };

  render() {
    const { count, inputText } = this.state;

    return (
      <div style={styles.container}>

        {/* Counter Section */}
        <div style={styles.section}>
          <h2 style={styles.sectionTitle}>Counter</h2>
          <p style={styles.label}>
            Click the buttons below. Each click changes state and triggers{" "}
            <code>componentDidUpdate()</code>.
          </p>
          <p style={styles.countText}>Current Count: {count}</p>
          <button style={styles.greenBtn} onClick={this.handleIncrement}>
            Increment
          </button>
          <button style={styles.redBtn} onClick={this.handleDecrement}>
            Decrement
          </button>
        </div>

        {/* Input Section */}
        <div style={styles.section}>
          <h2 style={styles.sectionTitle}>Text Input</h2>
          <p style={styles.label}>
            Type in the box below. Each keystroke triggers{" "}
            <code>componentDidUpdate()</code>.
          </p>
          <input
            type="text"
            value={inputText}
            onChange={this.handleInputChange}
            placeholder="Type here..."
            style={styles.input}
          />
          <p style={styles.preview}>
            Current value: <strong>{inputText || "(empty)"}</strong>
          </p>
        </div>

        {/* Console Log Reference */}
        <div style={styles.logBox}>
          <p style={styles.logTitle}>Expected Console Output:</p>
          <p style={styles.logLine}>
            On counter change: &nbsp;
            <code>componentDidUpdate() called - Count updated to: X</code>
          </p>
          <p style={styles.logLine}>
            On input change: &nbsp;
            <code>componentDidUpdate() called - Input changed to: "..."</code>
          </p>
          <p style={styles.logLine}>
            On unmount: &nbsp;
            <code>
              componentWillUnmount() called - LifecycleLogger has been removed
              from the DOM.
            </code>
          </p>
        </div>
      </div>
    );
  }
}

const styles = {
  container: {
    padding: "20px",
    border: "1px solid #ccc",
    borderRadius: "8px",
    backgroundColor: "#f0f8ff",
  },
  section: {
    backgroundColor: "#ffffff",
    border: "1px solid #dce3ea",
    borderRadius: "6px",
    padding: "16px",
    marginBottom: "16px",
  },
  sectionTitle: {
    fontSize: "18px",
    color: "#2c3e50",
    marginBottom: "8px",
  },
  label: {
    fontSize: "13px",
    color: "#555",
    marginBottom: "12px",
  },
  countText: {
    fontSize: "20px",
    fontWeight: "bold",
    color: "#2980b9",
    marginBottom: "12px",
  },
  greenBtn: {
    padding: "8px 18px",
    marginRight: "10px",
    backgroundColor: "#27ae60",
    color: "#fff",
    border: "none",
    borderRadius: "4px",
    cursor: "pointer",
    fontSize: "14px",
  },
  redBtn: {
    padding: "8px 18px",
    backgroundColor: "#e74c3c",
    color: "#fff",
    border: "none",
    borderRadius: "4px",
    cursor: "pointer",
    fontSize: "14px",
  },
  input: {
    width: "100%",
    padding: "10px",
    fontSize: "14px",
    border: "1px solid #ccc",
    borderRadius: "4px",
    boxSizing: "border-box",
  },
  preview: {
    marginTop: "10px",
    fontSize: "14px",
    color: "#444",
  },
  logBox: {
    backgroundColor: "#1e272e",
    color: "#dfe6e9",
    padding: "16px",
    borderRadius: "6px",
    fontSize: "13px",
    lineHeight: "1.9",
  },
  logTitle: {
    color: "#00b894",
    fontWeight: "bold",
    marginBottom: "6px",
  },
  logLine: {
    margin: "4px 0",
  },
};

export default LifecycleLogger;
